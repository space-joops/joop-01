우주 쓰레기 청소 위성 펫 — GLB 캐릭터 에셋 v1.0
================================================
glTF 2.0 / Y-up / +Z 정면 / 단위 m / Unity·Unreal·Godot·Blender 직접 임포트

pet_stage1_baby.glb    1단계 아기 위성 (1U 큐브샛)
pet_stage2_junior.glb  2단계 청소년 위성 (로봇 팔 + 2단 패널 + 통신 접시)
pet_stage3_net.glb     3단계 성체 — 그물망 특화
pet_stage3_magnet.glb  3단계 성체 — 자석 특화
pet_stage3_laser.glb   3단계 성체 — 레이저 요격 특화
support_drone.glb      보조 드론 (부재 중 자동 수리)

리깅 규약: PascalCase 노드만 애니메이션 대상. 모든 힌지·관절은
노드 원점에 피벗 정렬 → 회전값만 주면 파닥임/접힘/관절 동작.
  Antenna_Tip(rotZ 파닥·rotX 처짐) / Panel_L·R(+_Outer)(rotY 접힘)
  StatusLight(emissive=기분) / Arm_Shoulder→Upper→Fore→Claw_A·B
  Turret_Head(요)→Laser_Barrel(피치) / NetRing / Magnet_Tip_L·R
상태·수치·애니 파라미터는 character_data.json 참조.
재생성·치수 조정: gen_models.py (python3 + trimesh)
