# -*- coding: utf-8 -*-
"""
우주 쓰레기 청소 위성 펫 — 게임용 로우폴리 GLB 생성기
- Y-up / +Z 정면 / 단위 m / glTF 2.0 (GLB)
- 애니메이션 대상 노드는 PascalCase, 정적 장식은 lowercase 자식 노드
- 힌지/관절 피벗이 노드 원점에 오도록 지오메트리를 오프셋 (엔진에서 회전만 주면 접힘/파닥임)
"""
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.transformations import translation_matrix, rotation_matrix, concatenate_matrices

# ---------- 팔레트 (character_data.json 과 동일) ----------
PAL = {
    "body":        ("#EDF0F7", 0.10, 0.85, None),
    "body_dark":   ("#8E9AB4", 0.30, 0.70, None),
    "panel_cell":  ("#2E4FA3", 0.20, 0.55, None),
    "panel_frame": ("#17264F", 0.30, 0.60, None),
    "antenna":     ("#FFB13D", 0.35, 0.50, [0.10, 0.05, 0.00]),
    "eye":         ("#14E0D2", 0.00, 0.30, [0.05, 0.80, 0.75]),
    "eye_hi":      ("#FFFFFF", 0.00, 0.20, [0.60, 0.60, 0.60]),
    "cheek":       ("#F5A8B8", 0.00, 0.80, None),
    "mouth":       ("#3A4358", 0.00, 0.80, None),
    "arm":         ("#97A1B5", 0.60, 0.40, None),
    "thruster":    ("#5A6478", 0.50, 0.50, None),
    "net":         ("#57D08A", 0.40, 0.45, [0.02, 0.12, 0.06]),
    "magnet_red":  ("#F0564C", 0.30, 0.45, [0.20, 0.03, 0.02]),
    "magnet_coil": ("#4A7DF0", 0.40, 0.45, None),
    "laser_acc":   ("#A44CE0", 0.40, 0.40, None),
    "laser_lens":  ("#FF4D5E", 0.00, 0.20, [0.90, 0.15, 0.20]),
}

def hex2rgba(h):
    h = h.lstrip("#")
    return [int(h[i:i+2], 16)/255.0 for i in (0, 2, 4)] + [1.0]

_MATS = {}
def M(key):
    if key not in _MATS:
        hexc, met, rough, emis = PAL[key]
        _MATS[key] = PBRMaterial(name=key, baseColorFactor=hex2rgba(hexc),
                                 metallicFactor=met, roughnessFactor=rough,
                                 emissiveFactor=emis or [0, 0, 0])
    return _MATS[key]

def paint(mesh, key, facet=False):
    if facet:
        mesh.unmerge_vertices()
    mesh.visual = trimesh.visual.TextureVisuals(material=M(key))
    return mesh

def T(x, y, z):
    return translation_matrix([x, y, z])

def R(axis, deg, point=None):
    ax = {"x": [1, 0, 0], "y": [0, 1, 0], "z": [0, 0, 1]}[axis]
    return rotation_matrix(np.radians(deg), ax, point)

# ---------- 프리미티브 (로컬 오프셋을 지오메트리에 굽기) ----------
def box(ex, key, at=(0, 0, 0)):
    m = trimesh.creation.box(extents=ex)
    m.apply_transform(T(*at))
    return paint(m, key)

def cyl_y(r, h, key, at=(0, 0, 0), sections=10):
    """세로 원기둥, 밑면이 y=0 (at 기준)."""
    m = trimesh.creation.cylinder(radius=r, height=h, sections=sections)
    m.apply_transform(R("x", -90))
    m.apply_transform(T(at[0], at[1] + h/2, at[2]))
    return paint(m, key, facet=True)

def cyl_z(r, h, key, at=(0, 0, 0), sections=10):
    """정면(+Z) 원기둥, 밑면이 z=0 (at 기준)."""
    m = trimesh.creation.cylinder(radius=r, height=h, sections=sections)
    m.apply_transform(T(at[0], at[1], at[2] + h/2))
    return paint(m, key, facet=True)

def ball(r, key, at=(0, 0, 0)):
    m = trimesh.creation.icosphere(subdivisions=1, radius=r)
    m.apply_transform(T(*at))
    return paint(m, key, facet=True)

def ring_z(r_min, r_max, h, key, at=(0, 0, 0), sections=12):
    m = trimesh.creation.annulus(r_min=r_min, r_max=r_max, height=h, sections=sections)
    m.apply_transform(T(at[0], at[1], at[2] + h/2))
    return paint(m, key, facet=True)

def ring_y(r_min, r_max, h, key, at=(0, 0, 0), sections=12):
    m = trimesh.creation.annulus(r_min=r_min, r_max=r_max, height=h, sections=sections)
    m.apply_transform(R("x", -90))
    m.apply_transform(T(at[0], at[1] + h/2, at[2]))
    return paint(m, key, facet=True)

def cone_z(r, h, key, at=(0, 0, 0), sections=10):
    m = trimesh.creation.cone(radius=r, height=h, sections=sections)
    m.apply_transform(T(at[0], at[1], at[2]))
    return paint(m, key, facet=True)

def merge(meshes):
    """같은 노드에 들어갈 지오메트리 병합 (첫 재질 유지)이 아니라, 각각 자식 노드로 넣는다."""
    return meshes

class Builder:
    def __init__(self):
        self.scene = trimesh.Scene()
        self._i = 0

    def add(self, mesh, name, parent=None, tf=None):
        self.scene.add_geometry(mesh, node_name=name, geom_name=name + "_geo",
                                parent_node_name=parent, transform=tf)
        return name

    def deco(self, mesh, parent, tf=None):
        """정적 장식용 자식 노드 (소문자 접미)."""
        self._i += 1
        return self.add(mesh, f"{parent.lower()}_d{self._i}", parent=parent, tf=tf)

# ---------- 공용 부품 ----------
def add_face(b, parent, z_face, eye_r, eye_y, w):
    b.add(cyl_z(eye_r, 0.022, "eye", sections=14), "StatusLight", parent, T(0, eye_y, z_face + 0.002))
    b.deco(cyl_z(eye_r*0.26, 0.012, "eye_hi", sections=8), "StatusLight",
           T(eye_r*0.33, eye_r*0.33, 0.022))
    b.deco(box((w*0.20, 0.02, 0.012), "mouth"), parent, T(0, eye_y - eye_r - 0.075, z_face + 0.004))
    for sx in (-1, 1):
        b.deco(box((w*0.11, 0.032, 0.010), "cheek"), parent,
               T(sx*(eye_r + w*0.16), eye_y - eye_r*0.55, z_face + 0.004))

def add_rails(b, parent, w, h, d):
    t = min(w, d) * 0.075
    for sx in (-1, 1):
        for sz in (-1, 1):
            b.deco(box((t, h, t), "body_dark"), parent, T(sx*(w/2 - t/2), 0, sz*(d/2 - t/2)))

def add_antenna(b, parent, at, rod_h, tilt=0.0, suffix=""):
    base = b.add(cyl_y(0.032, 0.05, "body_dark"), f"Antenna{suffix}_Base", parent,
                 concatenate_matrices(T(*at), R("z", tilt)))
    tip = b.add(cyl_y(0.013, rod_h, "antenna", sections=8), f"Antenna{suffix}_Tip", base, T(0, 0.05, 0))
    b.deco(ball(rod_h*0.19, "antenna"), tip, T(0, rod_h, 0))
    return base, tip

def add_panel_pair(b, parent, hinge_x, y, seg1_w, seg1_h, seg2_w=None):
    names = []
    for side, sx in (("L", -1), ("R", 1)):
        p1 = b.add(box((seg1_w, seg1_h, 0.016), "panel_frame", at=(sx*(0.015 + seg1_w/2), 0, 0)),
                   f"Panel_{side}", parent, T(sx*hinge_x, y, 0))
        b.deco(box((seg1_w - 0.03, seg1_h - 0.03, 0.010), "panel_cell",
                   at=(sx*(0.015 + seg1_w/2), 0, 0.009)), p1)
        names.append(p1)
        if seg2_w:
            p2 = b.add(box((seg2_w, seg1_h - 0.02, 0.016), "panel_frame",
                           at=(sx*(0.012 + seg2_w/2), 0, 0)),
                       f"Panel_{side}_Outer", p1, T(sx*(0.02 + seg1_w), 0, 0))
            b.deco(box((seg2_w - 0.03, seg1_h - 0.05, 0.010), "panel_cell",
                       at=(sx*(0.012 + seg2_w/2), 0, 0.009)), p2)
            names.append(p2)
    return names

def add_thruster(b, parent, y_bottom, r):
    b.add(ring_y(r*0.62, r, 0.05, "thruster"), "Thruster", parent, T(0, y_bottom - 0.05, 0))

# ---------- 1단계: 아기 위성 ----------
def build_stage1():
    b = Builder()
    w, h, d = 0.50, 0.50, 0.50
    b.add(box((w, h, d), "body"), "Body")
    add_rails(b, "Body", w, h, d)
    add_face(b, "Body", d/2, eye_r=0.095, eye_y=0.055, w=w)
    add_antenna(b, "Body", (0, h/2, 0), rod_h=0.20)
    add_panel_pair(b, "Body", hinge_x=w/2, y=0.02, seg1_w=0.20, seg1_h=0.15)
    add_thruster(b, "Body", -h/2, r=0.062)
    return b.scene

# ---------- 2단계: 청소년 위성 ----------
def build_stage2():
    b = Builder()
    w, h, d = 0.56, 0.64, 0.52
    b.add(box((w, h, d), "body"), "Body")
    add_rails(b, "Body", w, h, d)
    add_face(b, "Body", d/2, eye_r=0.10, eye_y=0.085, w=w)
    add_antenna(b, "Body", (0, h/2, -0.02), rod_h=0.24)
    add_antenna(b, "Body", (-0.19, h/2, -0.16), rod_h=0.09, tilt=-14, suffix="_Sub")
    add_panel_pair(b, "Body", hinge_x=w/2, y=0.05, seg1_w=0.22, seg1_h=0.17, seg2_w=0.20)
    add_thruster(b, "Body", -h/2, r=0.070)
    # 통신 접시 (뒤)
    dish = b.add(cyl_z(0.028, 0.05, "arm"), "Dish", "Body",
                 concatenate_matrices(T(0, 0.10, -d/2), R("y", 180)))
    b.deco(cone_z(0.095, 0.045, "body_dark", sections=12), "Dish", T(0, 0, 0.05))
    # 로봇 팔 (오른쪽): Shoulder → Upper → Fore → Claw_A/B
    sh = b.add(ball(0.052, "arm"), "Arm_Shoulder", "Body",
               concatenate_matrices(T(w/2 + 0.02, 0.16, 0.10), R("y", -18)))
    b.deco(box((0.06, 0.09, 0.09), "body_dark", at=(-0.035, 0, 0)), "Arm_Shoulder")
    up_m = trimesh.creation.cylinder(radius=0.032, height=0.16, sections=8)
    up_m.apply_transform(R("y", 90)); up_m.apply_transform(T(0.08, 0, 0))
    up = b.add(paint(up_m, "arm", facet=True), "Arm_Upper", sh, T(0.03, 0, 0))
    b.deco(ball(0.045, "arm"), "Arm_Upper", T(0.16, 0, 0))
    fo = b.add(cyl_z(0.027, 0.16, "arm"), "Arm_Fore", up, T(0.16, 0, 0.01))
    b.deco(ball(0.04, "arm"), "Arm_Fore", T(0, 0, 0.16))
    for nm, sy, ang in (("Arm_Claw_A", 1, -16), ("Arm_Claw_B", -1, 16)):
        b.add(box((0.018, 0.042, 0.10), "body_dark", at=(0, sy*0.030, 0.052)),
              nm, fo, concatenate_matrices(T(0, 0, 0.16), R("x", ang)))
    return b.scene

# ---------- 3단계 공통 몸통 ----------
def stage3_base():
    b = Builder()
    w, h, d = 0.72, 0.78, 0.62
    b.add(box((w, h, d), "body"), "Body")
    add_rails(b, "Body", w, h, d)
    add_face(b, "Body", d/2, eye_r=0.11, eye_y=0.10, w=w)
    for side, sx, tilt in (("_L", -1, -12), ("_R", 1, 12)):
        add_antenna(b, "Body", (sx*0.20, h/2, 0), rod_h=0.22, tilt=tilt, suffix=side)
    add_panel_pair(b, "Body", hinge_x=w/2, y=0.06, seg1_w=0.26, seg1_h=0.20, seg2_w=0.24)
    add_thruster(b, "Body", -h/2, r=0.095)
    for i in range(3):  # 하부 통풍구 디테일
        b.deco(box((0.09, 0.018, 0.010), "body_dark"), "Body", T(-0.09 + i*0.09, -0.24, d/2 + 0.004))
    return b, w, h, d

# ---------- 3단계 분기 ----------
def build_stage3_net():
    b, w, h, d = stage3_base()
    ln = b.add(box((0.20, 0.18, 0.09), "body_dark", at=(0, 0, 0.03)), "NetLauncher", "Body",
               T(0, -0.05, d/2))
    b.add(ring_z(0.15, 0.19, 0.05, "net"), "NetRing", ln, T(0, 0, 0.09))
    for i, ang in enumerate((45, 135, 225, 315), 1):
        a = np.radians(ang)
        b.add(cone_z(0.026, 0.09, "net", sections=8),
              f"NetProng_{i}", "NetRing", T(0.165*np.cos(a), 0.165*np.sin(a), 0.115))
    return b.scene

def build_stage3_magnet():
    b, w, h, d = stage3_base()
    mu = b.add(box((0.30, 0.16, 0.10), "arm", at=(0, 0, 0.02)), "MagnetUnit", "Body",
               T(0, -0.05, d/2))
    for side, sx in (("L", -1), ("R", 1)):
        b.deco(cyl_z(0.055, 0.15, "arm", at=(sx*0.10, 0, 0.06)), "MagnetUnit")
        b.deco(ring_z(0.058, 0.078, 0.05, "magnet_coil", at=(sx*0.10, 0, 0.095)), "MagnetUnit")
        b.add(cyl_z(0.063, 0.07, "magnet_red"), f"Magnet_Tip_{side}", mu, T(sx*0.10, 0, 0.21))
    return b.scene

def build_stage3_laser():
    b, w, h, d = stage3_base()
    tb = b.add(cyl_y(0.12, 0.07, "body_dark", sections=12), "Turret_Base", "Body",
               T(0, h/2, 0.02))
    th = b.add(box((0.17, 0.13, 0.22), "body", at=(0, 0.065, 0)), "Turret_Head", tb, T(0, 0.07, 0))
    b.deco(box((0.174, 0.03, 0.224), "laser_acc"), "Turret_Head", T(0, 0.10, 0))
    bar = b.add(cyl_z(0.037, 0.22, "arm"), "Laser_Barrel", th, T(0, 0.075, 0.10))
    b.deco(ring_z(0.040, 0.056, 0.035, "laser_acc"), "Laser_Barrel", T(0, 0, 0.19))
    b.add(cyl_z(0.029, 0.016, "laser_lens", sections=12), "Laser_Lens", bar, T(0, 0, 0.222))
    return b.scene

# ---------- 보조 드론 ----------
def build_drone():
    b = Builder()
    w, h, d = 0.20, 0.17, 0.20
    b.add(box((w, h, d), "body"), "Body")
    add_face(b, "Body", d/2, eye_r=0.048, eye_y=0.018, w=w)
    add_antenna(b, "Body", (0, h/2, 0), rod_h=0.085)
    for side, sx in (("L", -1), ("R", 1)):
        p = b.add(box((0.085, 0.065, 0.012), "panel_frame", at=(sx*0.055, 0, 0)),
                  f"Panel_{side}", "Body", T(sx*w/2, 0.01, 0))
        b.deco(box((0.062, 0.045, 0.008), "panel_cell", at=(sx*0.055, 0, 0.007)), p)
    ra = b.add(cyl_z(0.013, 0.075, "arm"), "RepairArm", "Body", T(0, -0.045, d/2))
    for sy, ang in ((1, -18), (-1, 18)):
        b.deco(box((0.012, 0.020, 0.045), "body_dark", at=(0, sy*0.014, 0.022)), "RepairArm",
               concatenate_matrices(T(0, 0, 0.075), R("x", ang)))
    b.add(ring_y(0.020, 0.034, 0.03, "thruster"), "Thruster", "Body", T(0, -h/2 - 0.03, 0))
    return b.scene

# ---------- 내보내기 ----------
import os
OUT = "/home/claude/models"
os.makedirs(OUT, exist_ok=True)
MODELS = {
    "pet_stage1_baby":     build_stage1,
    "pet_stage2_junior":   build_stage2,
    "pet_stage3_net":      build_stage3_net,
    "pet_stage3_magnet":   build_stage3_magnet,
    "pet_stage3_laser":    build_stage3_laser,
    "support_drone":       build_drone,
}
for name, fn in MODELS.items():
    _MATS.clear()
    sc = fn()
    path = f"{OUT}/{name}.glb"
    sc.export(path)
    r = trimesh.load(path)
    rig = [n for n in r.graph.nodes if n != "world" and "_d" not in n.split("/")[-1][-4:]]
    print(f"{name}: {len(r.geometry)} geo, {os.path.getsize(path)//1024}KB")
print("DONE")
