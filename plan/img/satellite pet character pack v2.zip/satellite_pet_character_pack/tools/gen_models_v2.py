# -*- coding: utf-8 -*-
"""우주 쓰레기 청소 위성 펫 — 캐릭터 GLB v2 (큐트 리디자인)
· 라운드 바디(superellipsoid) + 빅 아이 + 볼터치 + 'o' 입 = 반려동물 감성
· 디테일 대폭 단순화(레일/그리블/접시 제거), 파스텔 팔레트
· 노드 계층·피벗·파일명은 v1 규약 그대로 (character_data.json rig 호환)
· glTF 2.0 / Y-up / +Z 정면 / 단위 m
"""
import numpy as np, trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.transformations import rotation_matrix as ROT, translation_matrix as TRA

OUT = "/home/claude/models"

PAL = dict(
    body="#FFF7EF", belly="#FFE3C9", panel="#8FC1EF", panel_in="#CDE4F9",
    antenna="#FFCE59", eye="#23D9CE", hi="#FFFFFF", cheek="#FFB1C1",
    mouth="#46536B", joint="#7C87A0", arm="#C7CEDB", thr="#97A0B3",
    net="#7FE0A8", mag_red="#FF8B7E", mag_tip="#FFF3E8",
    laser_acc="#C9A0F0", laser_lens="#FF8FA6",
)
def hx(h):
    h = h.lstrip("#"); return [int(h[i:i+2],16)/255 for i in (0,2,4)]
def mat(name, rough=0.8, metal=0.05, emis=None, ei=0.0):
    m = PBRMaterial(baseColorFactor=hx(PAL[name])+[1.0],
                    roughnessFactor=rough, metallicFactor=metal)
    if emis: m.emissiveFactor = [c*ei for c in hx(PAL[emis])]
    m.name = name; return m

M = dict(
    body=mat("body",0.85), belly=mat("belly",0.9), panel=mat("panel",0.6,0.1),
    pin=mat("panel_in",0.65), ant=mat("antenna",0.5,0.15,"antenna",0.25),
    eye=mat("eye",0.25,0.0,"eye",0.9), hi=mat("hi",0.2,0.0,"hi",0.6),
    cheek=mat("cheek",0.9), mouth=mat("mouth",0.85), joint=mat("joint",0.7,0.2),
    arm=mat("arm",0.6,0.25), thr=mat("thr",0.6,0.3),
    net=mat("net",0.5,0.1,"net",0.2), magR=mat("mag_red",0.55,0.1),
    magT=mat("mag_tip",0.7), lacc=mat("laser_acc",0.55,0.1),
    llens=mat("laser_lens",0.25,0.0,"laser_lens",0.9),
)

# ── 지오메트리 헬퍼 ─────────────────────────────────────────
def sqbox(w,h,d,n=4.0,sub=3):
    """superellipsoid: 모서리가 둥근 '두부' 박스 (귀여움의 핵심)"""
    m = trimesh.creation.icosphere(subdivisions=sub, radius=1.0)
    v = m.vertices
    r = (np.abs(v)**n).sum(axis=1)**(1.0/n)
    m.vertices = v/r[:,None]*np.array([w,h,d])/2.0
    return m
def sphere(r,sub=2): return trimesh.creation.icosphere(subdivisions=sub, radius=r)
def cylY(r,h,seg=18): return trimesh.creation.cylinder(radius=r,height=h,sections=seg)
def cylZ(r,h,seg=18):
    c = cylY(r,h,seg); c.apply_transform(ROT(np.pi/2,[1,0,0])); return c
def cylX(r,h,seg=18):
    c = cylY(r,h,seg); c.apply_transform(ROT(np.pi/2,[0,0,1])); return c
def mv(g,x=0,y=0,z=0): g.apply_translation([x,y,z]); return g
def capX(r,h):
    return trimesh.util.concatenate([cylX(r,h), mv(sphere(r,2),-h/2), mv(sphere(r,2),h/2)])
def capZ(r,h):
    return trimesh.util.concatenate([cylZ(r,h), mv(sphere(r,2),0,0,-h/2), mv(sphere(r,2),0,0,h/2)])
def fz(t,n=4.0):  # 높이 t(-1..1)에서 superellipsoid 단면 축소율
    return (max(0.0,1.0-abs(t)**n))**(1.0/n)

class B:  # 씬 빌더: 노드 계층 + 피벗
    def __init__(self):
        self.s = trimesh.Scene()
        self.s.graph.update("Body", "world", matrix=np.eye(4))
        self._i = 0
    def node(self, name, parent, x=0,y=0,z=0, rz=0.0, ry=0.0, rx=0.0):
        Mx = TRA([x,y,z])
        for ang,ax in ((rz,[0,0,1]),(ry,[0,1,0]),(rx,[1,0,0])):
            if ang: Mx = Mx @ ROT(ang,ax)
        self.s.graph.update(name, parent, matrix=Mx)
        return name
    def geo(self, mesh, material, parent="Body", name=None):
        mesh.visual = trimesh.visual.TextureVisuals(material=material)
        self._i += 1
        self.s.add_geometry(mesh, node_name=name or f"d{self._i}",
                            parent_node_name=parent, transform=np.eye(4))

# ── 공통 파츠 ───────────────────────────────────────────────
def face(b, w,h,d, n, eyeR, ey, spacing, mouth=True, single=False):
    """빅 아이(=StatusLight) + 하이라이트 + 볼터치 + 'o' 입. 얼굴은 낮게(베이비 스키마)."""
    zf = lambda y: (d/2)*fz(2*y/h, n)
    b.node("StatusLight","Body")
    xs = [0.0] if single else [-spacing, spacing]
    for x in xs:
        z0 = zf(ey) - 0.012
        e = cylZ(eyeR, 0.02, 20); e.vertices[:,0]*=0.92           # 살짝 세로 타원
        b.geo(mv(e, x, ey, z0+0.01), M["eye"], "StatusLight")
        b.geo(mv(cylZ(eyeR*0.34,0.012,10), x-eyeR*0.30, ey+eyeR*0.30, z0+0.024), M["hi"], "StatusLight")
        b.geo(mv(cylZ(eyeR*0.15,0.012,8),  x+eyeR*0.36, ey-eyeR*0.28, z0+0.024), M["hi"], "StatusLight")
    if mouth:
        mo = sphere(0.011,2); mo.vertices*= [1.35,0.9,0.6]
        b.geo(mv(mo, 0, ey-eyeR-0.02, zf(ey-eyeR-0.02)-0.002), M["mouth"])
    cx = (spacing if not single else 0)+eyeR+0.028
    for sx in (-1,1):
        ch = cylZ(eyeR*0.5, 0.01, 12)
        b.geo(mv(ch, sx*cx, ey-eyeR*0.7, zf(ey-eyeR*0.7)-0.004), M["cheek"])

def body(b, w,h,d, n=4.2, belly=True):
    b.geo(sqbox(w,h,d,n), M["body"])
    if belly:
        t = sqbox(w*0.5, h*0.4, 0.04, 3.0, sub=2)
        b.geo(mv(t, 0, -h*0.1, d/2-0.014), M["belly"])

def antenna(b, prefix, parent, x,y,z, rod, ballR, tilt=0.0):
    base = b.node(prefix+"_Base", parent, x,y,z, rz=tilt)
    dome = sphere(0.016,2); dome.vertices[:,1]*=0.62
    b.geo(dome, M["joint"], base)
    tip = b.node(prefix+"_Tip", base, 0, 0.012, 0)
    b.geo(mv(cylY(0.0085, rod), 0, rod/2, 0), M["joint"], tip)
    b.geo(mv(sphere(ballR,2), 0, rod, 0), M["ant"], tip)

def wing(b, name, parent, sx, hx_, y, w1, h1, w2=0.0):
    """둥근 패들 날개. 힌지 피벗=노드 원점(v1 규약). 중립 포즈=수평."""
    p = b.node(name, parent, sx*hx_, y, 0)
    pad = sqbox(w1, h1, 0.026, 3.0, sub=2); mv(pad, sx*(0.012+w1/2), 0, 0)
    b.geo(pad, M["panel"], p)
    inn = sqbox(w1*0.72, h1*0.68, 0.02, 3.0, sub=2); mv(inn, sx*(0.012+w1/2), 0, 0.008)
    b.geo(inn, M["pin"], p)
    if w2:
        o = b.node(name+"_Outer", p, sx*(0.02+w1), 0, 0)
        pad2 = sqbox(w2, h1*0.85, 0.024, 3.0, sub=2); mv(pad2, sx*(0.01+w2/2), 0, 0)
        b.geo(pad2, M["panel"], o)
        inn2 = sqbox(w2*0.7, h1*0.55, 0.018, 3.0, sub=2); mv(inn2, sx*(0.01+w2/2), 0, 0.007)
        b.geo(inn2, M["pin"], o)

def tail(b, yb):
    t = b.node("Thruster","Body", 0, yb, 0)
    nub = sphere(0.028,2); nub.vertices[:,1]*=0.7
    b.geo(nub, M["thr"], t)

# ── 모델 6종 ────────────────────────────────────────────────
def stage1():
    b=B(); w,h,d,n = 0.24,0.20,0.20,4.2
    body(b,w,h,d,n)
    face(b,w,h,d,n, eyeR=0.036, ey=-0.006, spacing=0.052)
    antenna(b,"Antenna","Body", 0, h/2-0.004, 0, rod=0.07, ballR=0.024)
    for sx in (-1,1): wing(b, f"Panel_{'L' if sx<0 else 'R'}","Body", sx, w/2-0.006, -0.01, 0.095, 0.062)
    tail(b, -h/2+0.006)
    return b.s

def stage2():
    b=B(); w,h,d,n = 0.26,0.23,0.21,4.2
    body(b,w,h,d,n)
    face(b,w,h,d,n, eyeR=0.038, ey=0.0, spacing=0.056)
    antenna(b,"Antenna","Body", 0, h/2-0.004, 0, rod=0.085, ballR=0.026)
    for sx in (-1,1): wing(b, f"Panel_{'L' if sx<0 else 'R'}","Body", sx, w/2-0.006, 0.0, 0.1, 0.066, 0.085)
    tail(b, -h/2+0.006)
    # 통통한 로봇 팔 (미튼 집게)
    sh = b.node("Arm_Shoulder","Body", w/2-0.01, 0.035, 0.04, ry=-0.3)
    b.geo(sphere(0.024,2), M["arm"], sh)
    up = b.node("Arm_Upper", sh, 0.012, 0, 0)
    b.geo(mv(capX(0.016,0.05), 0.037, 0, 0), M["arm"], up)
    fo = b.node("Arm_Fore", up, 0.074, 0, 0.004)
    b.geo(sphere(0.019,2), M["arm"], fo)
    b.geo(mv(capZ(0.014,0.05), 0, 0, 0.035), M["arm"], fo)
    for nm, sy, a in (("Arm_Claw_A", 1,-0.34),("Arm_Claw_B",-1,0.34)):
        c = b.node(nm, fo, 0, 0, 0.062, rx=a)
        pad = sqbox(0.024,0.015,0.04,3.0,sub=2)
        b.geo(mv(pad, 0, sy*0.011, 0.02), M["joint"], c)
    return b.s

def stage3(kind):
    b=B(); w,h,d,n = 0.30,0.26,0.24,4.2
    body(b,w,h,d,n)
    face(b,w,h,d,n, eyeR=0.042, ey=0.008, spacing=0.064)
    for sx in (-1,1):  # 쫑긋 귀 안테나
        antenna(b, f"Antenna_{'L' if sx<0 else 'R'}","Body",
                sx*0.088, h/2-0.012, 0, rod=0.075, ballR=0.027, tilt=-sx*0.24)
    for sx in (-1,1): wing(b, f"Panel_{'L' if sx<0 else 'R'}","Body", sx, w/2-0.008, 0.005, 0.115, 0.075, 0.095)
    tail(b, -h/2+0.008)
    if kind=="net":
        ln = b.node("NetLauncher","Body", 0.132, 0.075, 0.055, ry=-0.32)
        b.geo(sqbox(0.062,0.055,0.05,3.2,sub=2), M["joint"], ln)
        ring = b.node("NetRing", ln, 0, 0, 0.05)
        b.geo(trimesh.creation.torus(0.055, 0.012), M["net"], ring)
        for i,a in enumerate((45,135,225,315)):
            r = np.radians(a)
            b.geo(mv(sphere(0.013,2), 0.055*np.cos(r), 0.055*np.sin(r), 0), M["net"],
                  ring, name=f"NetProng_{i+1}")
    elif kind=="magnet":
        mu = b.node("MagnetUnit","Body", 0.135, -0.02, 0.05, ry=-0.26)
        b.geo(sqbox(0.05,0.05,0.045,3.2,sub=2), M["joint"], mu)
        # 동글동글 말굽자석: 구슬 아치 + 두 극
        for a in np.linspace(np.radians(35), np.radians(145), 5):
            b.geo(mv(sphere(0.02,2), 0.042*np.cos(a), 0.042*np.sin(a)-0.005, 0.04), M["magR"], mu)
        for nm,sx in (("Magnet_Tip_L",-1),("Magnet_Tip_R",1)):
            b.geo(mv(capZ(0.017,0.03), sx*0.037, 0.005, 0.062), M["magR"], mu)
            tipn = b.node(nm, mu, sx*0.037, 0.005, 0.085)
            b.geo(cylZ(0.019,0.02,14), M["magT"], tipn)
    else:  # laser
        tb = b.node("Turret_Base","Body", 0.115, h/2-0.02, 0.02)
        dome = sphere(0.03,2); dome.vertices[:,1]*=0.7
        b.geo(dome, M["joint"], tb)
        th = b.node("Turret_Head", tb, 0, 0.026, 0)
        b.geo(sqbox(0.055,0.045,0.06,3.2,sub=2), M["lacc"], th)
        bar = b.node("Laser_Barrel", th, 0, 0.004, 0.032)
        b.geo(mv(capZ(0.013,0.05), 0, 0, 0.026), M["arm"], bar)
        b.geo(mv(sphere(0.017,2), 0, 0, 0.062), M["llens"], bar, name="Laser_Lens")
    return b.s

def drone():
    b=B(); w,h,d,n = 0.115,0.1,0.108,3.6
    body(b,w,h,d,n, belly=False)
    face(b,w,h,d,n, eyeR=0.03, ey=0.004, spacing=0, single=True)   # 외눈 = 시클롭스
    antenna(b,"Antenna","Body", 0, h/2-0.003, 0, rod=0.042, ballR=0.017)
    for sx in (-1,1): wing(b, f"Panel_{'L' if sx<0 else 'R'}","Body", sx, w/2-0.004, 0.004, 0.048, 0.034)
    tail(b, -h/2+0.004)
    ra = b.node("RepairArm","Body", 0, -0.028, d/2-0.01)
    b.geo(mv(capZ(0.008,0.04), 0, 0, 0.024), M["arm"], ra)
    for sy,a in ((1,-0.36),(-1,0.36)):
        pad = sqbox(0.014,0.009,0.024,3.0,sub=2)
        pad.apply_transform(ROT(a,[1,0,0]))
        b.geo(mv(pad, 0, sy*0.008, 0.052), M["joint"], ra)
    return b.s

# ── 내보내기 ────────────────────────────────────────────────
import os
os.makedirs(OUT, exist_ok=True)
jobs = [("pet_stage1_baby", stage1()), ("pet_stage2_junior", stage2()),
        ("pet_stage3_net", stage3("net")), ("pet_stage3_magnet", stage3("magnet")),
        ("pet_stage3_laser", stage3("laser")), ("support_drone", drone())]
for nm, sc in jobs:
    p = f"{OUT}/{nm}.glb"; sc.export(p)
    tris = sum(len(g.faces) for g in sc.geometry.values())
    print(f"{nm:22s} {os.path.getsize(p)//1024:4d}KB  {tris:5d} tris  nodes={len(sc.graph.nodes)}")
print("DONE")
