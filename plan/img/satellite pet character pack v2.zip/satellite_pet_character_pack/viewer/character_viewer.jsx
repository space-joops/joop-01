import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

/* ─────────────────────────────────────────────────────────────
   우주 쓰레기 청소 위성 펫 — 캐릭터 관제 콘솔 (뷰어)
   · GLB 산출물과 동일한 노드 계층/치수/팔레트의 레퍼런스 구현
   · 감정 상태머신 · 제스처(탭=기쁨 / 문지르기=쓰다듬기 / 동면 중 문지르기=깨우기)
   · character_data.json 의 animations 사양과 1:1 대응
   ───────────────────────────────────────────────────────────── */

const PAL = {
  body: 0xfff7ef, belly: 0xffe3c9, panel: 0x8fc1ef, panelIn: 0xcde4f9,
  antenna: 0xffce59, eye: 0x23d9ce, arm: 0xc7cedb, joint: 0x7c87a0, thruster: 0x97a0b3,
  net: 0x7fe0a8, magRed: 0xff8b7e, magTip: 0xfff3e8,
  laserAcc: 0xc9a0f0, laserLens: 0xff8fa6, cheek: 0xffb1c1, mouth: 0x46536b,
};

const MODELS = [
  { id: "s1", label: "1단계", name: "아기 위성", trait: "1U 큐브샛 · 안테나 파닥임", dist: 1.55 },
  { id: "s2", label: "2단계", name: "청소년 위성", trait: "로봇 팔 장착 · 수집 효율↑", dist: 1.85 },
  { id: "s3net", label: "3단계", name: "성체 · 그물망 특화", trait: "광역 포획 — 포획 반경↑", dist: 2.15 },
  { id: "s3mag", label: "3단계", name: "성체 · 자석 특화", trait: "금속 파편 흡착 — 방치 수집↑", dist: 2.15 },
  { id: "s3las", label: "3단계", name: "성체 · 레이저 특화", trait: "탭 요격 강화 — 차지샷 관통", dist: 2.15 },
  { id: "drone", label: "보조", name: "보조 드론", trait: "부재 중 자동 수리 담당", dist: 0.95 },
];

const EMOTIONS = [
  { id: "normal", label: "평상", info: "코어 루프 대기 · 표정으로 상태 읽기" },
  { id: "happy", label: "기쁨", info: "상호작용 반응 — 안테나 파닥임", burst: true },
  { id: "low_battery", label: "배터리 부족", info: "battery < 25 · 나른함 — 충전 필요" },
  { id: "data_full", label: "데이터 만충", info: "data ≥ 95 · 수집 효율 50%↓ — 전송 필요" },
  { id: "sulky", label: "시무룩", info: "방치 6~12시간 · 수집 효율 소폭 감소" },
  { id: "powersave", label: "절전", info: "방치 1~3일 · 자동 수집 정지 (자원 보존)" },
  { id: "hibernate", label: "동면", info: "방치 1주+ · 화면을 문질러 깨우기" },
];

/* ── 재질/지오메트리 헬퍼 (GLB 생성 스크립트와 동일 규격) ── */
function mkMat(hex, met = 0.15, rough = 0.8, emis = 0x000000, ei = 0, flat = false) {
  return new THREE.MeshStandardMaterial({
    color: hex, metalness: met, roughness: rough, flatShading: flat,
    emissive: emis, emissiveIntensity: ei,
  });
}
const sq = (w, h, d, m, n = 4, x = 0, y = 0, z = 0, ws = 22, hs = 16) => {
  const g = new THREE.SphereGeometry(1, ws, hs);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const vx = p.getX(i), vy = p.getY(i), vz = p.getZ(i);
    const r = Math.pow(Math.pow(Math.abs(vx), n) + Math.pow(Math.abs(vy), n) + Math.pow(Math.abs(vz), n), 1 / n) || 1;
    p.setXYZ(i, (vx / r) * w / 2, (vy / r) * h / 2, (vz / r) * d / 2);
  }
  g.computeVertexNormals();
  const o = new THREE.Mesh(g, m); o.position.set(x, y, z); return o;
};
const ball = (r, m, x = 0, y = 0, z = 0, sub = 14) => {
  const o = new THREE.Mesh(new THREE.SphereGeometry(r, sub, Math.max(8, sub - 4)), m);
  o.position.set(x, y, z); return o;
};
const cylY = (r, h, m, x = 0, y = 0, z = 0, seg = 14) => {
  const o = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, seg), m);
  o.position.set(x, y, z); return o;
};
const cylZ = (r, h, m, x = 0, y = 0, z = 0, seg = 14) => {
  const o = cylY(r, h, m, x, y, z, seg); o.rotation.x = Math.PI / 2; return o;
};
const capZ = (r, h, m, z = 0) => {
  const g = new THREE.Group(); g.position.z = z;
  g.add(cylZ(r, h, m)); g.add(ball(r, m, 0, 0, -h / 2)); g.add(ball(r, m, 0, 0, h / 2));
  return g;
};
const capX = (r, h, m, x = 0) => {
  const g = new THREE.Group(); g.position.x = x; g.rotation.y = Math.PI / 2;
  g.add(cylZ(r, h, m)); g.add(ball(r, m, 0, 0, -h / 2)); g.add(ball(r, m, 0, 0, h / 2));
  return g;
};
const fzf = (t, n) => Math.pow(Math.max(0, 1 - Math.pow(Math.abs(t), n)), 1 / n);

/* ── 캐릭터 빌더: GLB v2(큐트 리디자인)와 동일 수치 · root.scale로 표시 배율 ── */
function buildPet(id) {
  const M = {
    body: mkMat(PAL.body, 0.05, 0.85), belly: mkMat(PAL.belly, 0.05, 0.9),
    panel: mkMat(PAL.panel, 0.1, 0.6), pin: mkMat(PAL.panelIn, 0.05, 0.65),
    ant: mkMat(PAL.antenna, 0.15, 0.5, PAL.antenna, 0.25),
    eye: mkMat(PAL.eye, 0, 0.25, PAL.eye, 0.9),
    hi: mkMat(0xffffff, 0, 0.2, 0xffffff, 0.6),
    cheek: mkMat(PAL.cheek, 0, 0.9), mouth: mkMat(PAL.mouth, 0, 0.85),
    joint: mkMat(PAL.joint, 0.2, 0.7), arm: mkMat(PAL.arm, 0.25, 0.6),
    thr: mkMat(PAL.thruster, 0.3, 0.6),
    net: mkMat(PAL.net, 0.1, 0.5, PAL.net, 0.2),
    magR: mkMat(PAL.magRed, 0.1, 0.55), magT: mkMat(PAL.magTip, 0.05, 0.7),
    lacc: mkMat(PAL.laserAcc, 0.1, 0.55), llens: mkMat(PAL.laserLens, 0, 0.25, PAL.laserLens, 0.9),
  };
  const root = new THREE.Group(); root.scale.setScalar(2.1);
  const parts = { root, eyeMat: M.eye, tips: [], panels: [], outers: [], extras: {} };

  const face = (n, d, h, eyeR, ey, sp, single = false) => {
    const zf = (y) => (d / 2) * fzf((2 * y) / h, n);
    (single ? [0] : [-sp, sp]).forEach(x => {
      const z0 = zf(ey) - 0.012;
      const e = cylZ(eyeR, 0.02, M.eye, x, ey, z0 + 0.01, 18); e.scale.x = 0.92; root.add(e);
      root.add(cylZ(eyeR * 0.34, 0.012, M.hi, x - eyeR * 0.3, ey + eyeR * 0.3, z0 + 0.024, 10));
      root.add(cylZ(eyeR * 0.15, 0.012, M.hi, x + eyeR * 0.36, ey - eyeR * 0.28, z0 + 0.024, 8));
    });
    const mo = ball(0.011, M.mouth, 0, ey - eyeR - 0.02, zf(ey - eyeR - 0.02) - 0.002, 10);
    mo.scale.set(1.35, 0.9, 0.6); root.add(mo);
    const cx = (single ? 0 : sp) + eyeR + 0.028;
    [-1, 1].forEach(sx =>
      root.add(cylZ(eyeR * 0.5, 0.01, M.cheek, sx * cx, ey - eyeR * 0.7, zf(ey - eyeR * 0.7) - 0.004, 12)));
  };
  const bodyGeo = (w, h, d, n, belly = true) => {
    root.add(sq(w, h, d, M.body, n));
    if (belly) root.add(sq(w * 0.5, h * 0.4, 0.04, M.belly, 3, 0, -h * 0.1, d / 2 - 0.014));
  };
  const antenna = (x, y, z, rod, ballR, tilt = 0, dir = 1) => {
    const base = new THREE.Group(); base.position.set(x, y, z); base.rotation.z = tilt; root.add(base);
    const dome = ball(0.016, M.joint); dome.scale.y = 0.62; base.add(dome);
    const tip = new THREE.Group(); tip.position.y = 0.012; base.add(tip);
    tip.add(cylY(0.0085, rod, M.joint, 0, rod / 2, 0, 10));
    tip.add(ball(ballR, M.ant, 0, rod, 0));
    parts.tips.push({ g: tip, dir });
  };
  const wing = (sx, hx, y, w1, h1, w2 = 0) => {
    const mount = new THREE.Group(); mount.position.set(sx * hx, y, 0);
    mount.rotation.z = -sx * 0.1; root.add(mount);           // 살짝 처진 플리퍼 느낌(뷰어 연출)
    const p = new THREE.Group(); mount.add(p);
    p.add(sq(w1, h1, 0.026, M.panel, 3, sx * (0.012 + w1 / 2), 0, 0));
    p.add(sq(w1 * 0.72, h1 * 0.68, 0.02, M.pin, 3, sx * (0.012 + w1 / 2), 0, 0.008));
    parts.panels.push({ g: p, sx });
    if (w2) {
      const o = new THREE.Group(); o.position.set(sx * (0.02 + w1), 0, 0); p.add(o);
      o.add(sq(w2, h1 * 0.85, 0.024, M.panel, 3, sx * (0.01 + w2 / 2), 0, 0));
      o.add(sq(w2 * 0.7, h1 * 0.55, 0.018, M.pin, 3, sx * (0.01 + w2 / 2), 0, 0.007));
      parts.outers.push({ g: o, sx });
    }
  };
  const tail = (yb) => {
    const nub = ball(0.028, M.thr, 0, yb, 0); nub.scale.y = 0.7; root.add(nub);
  };

  if (id === "s1") {
    const w = 0.24, h = 0.20, d = 0.20, n = 4.2;
    bodyGeo(w, h, d, n);
    face(n, d, h, 0.036, -0.006, 0.052);
    antenna(0, h / 2 - 0.004, 0, 0.07, 0.024);
    [-1, 1].forEach(sx => wing(sx, w / 2 - 0.006, -0.01, 0.095, 0.062));
    tail(-h / 2 + 0.006);
  } else if (id === "s2") {
    const w = 0.26, h = 0.23, d = 0.21, n = 4.2;
    bodyGeo(w, h, d, n);
    face(n, d, h, 0.038, 0, 0.056);
    antenna(0, h / 2 - 0.004, 0, 0.085, 0.026);
    [-1, 1].forEach(sx => wing(sx, w / 2 - 0.006, 0, 0.1, 0.066, 0.085));
    tail(-h / 2 + 0.006);
    const sh = new THREE.Group(); sh.position.set(w / 2 - 0.01, 0.035, 0.04); sh.rotation.y = -0.3; root.add(sh);
    sh.add(ball(0.024, M.arm));
    const up = new THREE.Group(); up.position.x = 0.012; sh.add(up);
    up.add(capX(0.016, 0.05, M.arm, 0.037));
    const fo = new THREE.Group(); fo.position.set(0.074, 0, 0.004); up.add(fo);
    fo.add(ball(0.019, M.arm)); fo.add(capZ(0.014, 0.05, M.arm, 0.035));
    const claws = [];
    [[1, -0.34], [-1, 0.34]].forEach(([sy, a]) => {
      const c = new THREE.Group(); c.position.set(0, 0, 0.062); c.rotation.x = a; fo.add(c);
      c.add(sq(0.024, 0.015, 0.04, M.joint, 3, 0, sy * 0.011, 0.02)); claws.push({ g: c, base: a });
    });
    parts.extras.arm = { sh, up, fo, claws, shBase: -0.3 };
  } else if (id.startsWith("s3")) {
    const w = 0.30, h = 0.26, d = 0.24, n = 4.2;
    bodyGeo(w, h, d, n);
    face(n, d, h, 0.042, 0.008, 0.064);
    antenna(-0.088, h / 2 - 0.012, 0, 0.075, 0.027, 0.24, 1);
    antenna(0.088, h / 2 - 0.012, 0, 0.075, 0.027, -0.24, -1);
    [-1, 1].forEach(sx => wing(sx, w / 2 - 0.008, 0.005, 0.115, 0.075, 0.095));
    tail(-h / 2 + 0.008);
    if (id === "s3net") {
      const ln = new THREE.Group(); ln.position.set(0.132, 0.075, 0.055); ln.rotation.y = -0.32; root.add(ln);
      ln.add(sq(0.062, 0.055, 0.05, M.joint, 3.2));
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.012, 10, 26), M.net);
      ring.position.z = 0.05; ln.add(ring);
      [45, 135, 225, 315].forEach(a => {
        const r = (a * Math.PI) / 180;
        ring.add(ball(0.013, M.net, 0.055 * Math.cos(r), 0.055 * Math.sin(r), 0));
      });
      parts.extras.netRing = ring;
    } else if (id === "s3mag") {
      const mu = new THREE.Group(); mu.position.set(0.135, -0.02, 0.05); mu.rotation.y = -0.26; root.add(mu);
      mu.add(sq(0.05, 0.05, 0.045, M.joint, 3.2));
      for (let i = 0; i < 5; i++) {
        const a = (35 + (110 * i) / 4) * (Math.PI / 180);
        mu.add(ball(0.02, M.magR, 0.042 * Math.cos(a), 0.042 * Math.sin(a) - 0.005, 0.04));
      }
      [-1, 1].forEach(sx => {
        mu.add(capZ(0.017, 0.03, M.magR, 0).translateX(sx * 0.037).translateY(0.005).translateZ(0.062));
        mu.add(cylZ(0.019, 0.02, M.magT, sx * 0.037, 0.005, 0.085, 16));
      });
    } else {
      const tb = new THREE.Group(); tb.position.set(0.115, h / 2 - 0.02, 0.02); root.add(tb);
      const dome = ball(0.03, M.joint); dome.scale.y = 0.7; tb.add(dome);
      const th = new THREE.Group(); th.position.y = 0.026; tb.add(th);
      th.add(sq(0.055, 0.045, 0.06, M.lacc, 3.2));
      const bar = new THREE.Group(); bar.position.set(0, 0.004, 0.032); th.add(bar);
      bar.add(capZ(0.013, 0.05, M.arm, 0.026)); bar.add(ball(0.017, M.llens, 0, 0, 0.062));
      parts.extras.turret = { head: th, bar };
    }
  } else { // 보조 드론 (외눈 시클롭스)
    const w = 0.115, h = 0.1, d = 0.108, n = 3.6;
    bodyGeo(w, h, d, n, false);
    face(n, d, h, 0.03, 0.004, 0, true);
    antenna(0, h / 2 - 0.003, 0, 0.042, 0.017);
    [-1, 1].forEach(sx => wing(sx, w / 2 - 0.004, 0.004, 0.048, 0.034));
    tail(-h / 2 + 0.004);
    const ra = new THREE.Group(); ra.position.set(0, -0.028, d / 2 - 0.01); root.add(ra);
    ra.add(capZ(0.008, 0.04, M.arm, 0.024));
    [[1, -0.36], [-1, 0.36]].forEach(([sy, a]) => {
      const pad = sq(0.014, 0.009, 0.024, M.joint, 3);
      pad.rotation.x = a; pad.position.set(0, sy * 0.008, 0.052); ra.add(pad);
    });
    parts.extras.isDrone = true;
  }
  return parts;
}

/* ── 배경: 각진 별 · 다면체 지구 · 표류 파편 ── */
function buildSpace(scene) {
  const starGeo = new THREE.BufferGeometry();
  const pos = new Float32Array(1800);
  for (let i = 0; i < 600; i++) {
    const r = 22 + Math.random() * 26, t = Math.random() * Math.PI * 2, p = Math.acos(2 * Math.random() - 1);
    pos[i * 3] = r * Math.sin(p) * Math.cos(t); pos[i * 3 + 1] = r * Math.cos(p); pos[i * 3 + 2] = r * Math.sin(p) * Math.sin(t);
  }
  starGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xcfe0ff, size: 0.06, sizeAttenuation: true, transparent: true, opacity: 0.85 })));

  const earth = new THREE.Mesh(new THREE.IcosahedronGeometry(2.3, 1),
    mkMat(0x2c6bd9, 0.05, 0.9, 0x0a2b66, 0.35, true));
  earth.position.set(-3.4, -2.7, -6); scene.add(earth);
  const cap = new THREE.Mesh(new THREE.IcosahedronGeometry(2.33, 1),
    new THREE.MeshStandardMaterial({ color: 0xaad4ff, flatShading: true, transparent: true, opacity: 0.14 }));
  cap.position.copy(earth.position); scene.add(cap);

  const debris = [];
  const dm = mkMat(0x6a7690, 0.5, 0.7, 0, 0, true);
  for (let i = 0; i < 9; i++) {
    const c = sq(0.05 + Math.random() * 0.05, 0.045, 0.045, dm, 3.2, 0, 0, 0, 10, 8);
    c.userData = { r: 1.6 + Math.random() * 1.3, sp: 0.05 + Math.random() * 0.08, ph: Math.random() * 6.28, yo: (Math.random() - 0.5) * 1.2 };
    scene.add(c); debris.push(c);
  }
  return { earth, debris };
}

export default function SatellitePetViewer() {
  const mountRef = useRef(null);
  const apiRef = useRef(null);
  const [modelId, setModelId] = useState("s1");
  const [emotion, setEmotion] = useState("normal");
  const [toast, setToast] = useState(null);
  const emoRef = useRef("normal");
  const toastTimer = useRef(null);

  const showToast = (msg) => {
    setToast(msg); clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  };

  useEffect(() => { emoRef.current = emotion; }, [emotion]);

  useEffect(() => {
    const el = mountRef.current; if (!el) return;
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const scene = new THREE.Scene(); scene.background = new THREE.Color(0x070c1a);
    scene.fog = new THREE.Fog(0x070c1a, 14, 46);
    const cam = new THREE.PerspectiveCamera(42, 1, 0.05, 120);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputEncoding = THREE.sRGBEncoding;
    el.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0x9fb8ff, 0x1a2440, 0.8));
    const key = new THREE.DirectionalLight(0xfff4e0, 0.95); key.position.set(1.4, 2.2, 1.6); scene.add(key);
    const rim = new THREE.DirectionalLight(0x7df5ea, 0.35); rim.position.set(-2, 0.6, -2); scene.add(rim);

    const { earth, debris } = buildSpace(scene);

    let pet = null;
    const st = {
      droop: 0, fold: 0, floatK: 1, flapT: -9, petting: false, scrub: 0,
      camAz: -0.55, camPol: 1.2, camDist: 1.55, camDistT: 1.55, lastPtr: 0,
      eyePhase: 0, nextBlink: 2.5, wakeFlash: 0,
    };
    const swap = (id) => {
      if (pet) { scene.remove(pet.root); pet.root.traverse(o => { if (o.geometry) o.geometry.dispose(); }); }
      pet = buildPet(id); scene.add(pet.root);
      st.camDistT = MODELS.find(m => m.id === id).dist;
    };
    swap("s1");

    const size = () => {
      const w = el.clientWidth, h = el.clientHeight;
      renderer.setSize(w, h); cam.aspect = w / h; cam.updateProjectionMatrix();
    };
    size();
    const ro = new ResizeObserver(size); ro.observe(el);

    /* ── 포인터: 빈 공간 드래그=궤도 / 위성 문지르기=쓰다듬기·깨우기 / 탭=기쁨 ── */
    const ray = new THREE.Raycaster(); const ndc = new THREE.Vector2();
    const ptrs = new Map(); let mode = null, downT = 0, moved = 0, pinch0 = 0, dist0 = 0;
    const hitPet = (e) => {
      const r = renderer.domElement.getBoundingClientRect();
      ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
      ray.setFromCamera(ndc, cam);
      return ray.intersectObject(pet.root, true).length > 0;
    };
    const onDown = (e) => {
      ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      st.lastPtr = performance.now() / 1000;
      if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        pinch0 = Math.hypot(a.x - b.x, a.y - b.y); dist0 = st.camDistT; mode = "pinch"; return;
      }
      downT = performance.now(); moved = 0; st.scrub = 0;
      mode = hitPet(e) ? "pet" : "orbit";
      if (mode === "pet" && emoRef.current !== "hibernate") st.petting = true;
    };
    const onMove = (e) => {
      const p = ptrs.get(e.pointerId); if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      st.lastPtr = performance.now() / 1000;
      if (mode === "pinch" && ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        st.camDistT = Math.min(6, Math.max(0.7, dist0 * (pinch0 / Math.max(d, 1)))); return;
      }
      moved += Math.abs(dx) + Math.abs(dy);
      if (mode === "orbit") {
        st.camAz -= dx * 0.0065;
        st.camPol = Math.min(2.5, Math.max(0.5, st.camPol - dy * 0.005));
      } else if (mode === "pet") {
        st.scrub += Math.abs(dx) + Math.abs(dy);
        if (emoRef.current === "hibernate" && st.scrub > 90) {
          setEmotion("normal"); emoRef.current = "normal";
          st.wakeFlash = 1; st.flapT = performance.now() / 1000 + 0.55;
          showToast("복귀 시퀀스 — 찌그러진 안테나로도 파닥이며 반겨요");
          mode = null; st.petting = false;
        }
      }
    };
    const onUp = (e) => {
      ptrs.delete(e.pointerId);
      const wasTap = mode === "pet" && moved < 9 && performance.now() - downT < 320;
      if (wasTap && emoRef.current !== "hibernate") {
        st.flapT = performance.now() / 1000;
        showToast("탭 = 함께 일하는 신호 · 안테나 파닥!");
      }
      st.petting = false; if (ptrs.size < 2) mode = ptrs.size === 1 ? "orbit" : null;
    };
    const onWheel = (e) => { st.camDistT = Math.min(6, Math.max(0.7, st.camDistT + e.deltaY * 0.0015)); };
    const dom = renderer.domElement;
    dom.style.touchAction = "none";
    dom.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    dom.addEventListener("wheel", onWheel, { passive: true });

    /* ── 감정 상태 → 목표 포즈/눈빛 (character_data.json emotion_states) ── */
    const EYE = {
      normal: { c: 0x14e0d2, mode: "nat", base: 0.95 },
      low_battery: { c: 0xffb13d, mode: "heavy", base: 0.55 },
      data_full: { c: 0x14e0d2, mode: "fast", base: 0.95 },
      sulky: { c: 0xe8b84a, mode: "dim", base: 0.4 },
      powersave: { c: 0xff8a3d, mode: "pulse", base: 0.35 },
      hibernate: { c: 0x9adfe0, mode: "off", base: 0 },
    };
    const target = () => {
      const e = emoRef.current;
      if (e === "sulky") return { droop: 0.9, fold: 0, floatK: 0.45 };
      if (e === "powersave") return { droop: 1.2, fold: 0.8, floatK: 0.25 };
      if (e === "hibernate") return { droop: 1.4, fold: 1, floatK: 0 };
      if (e === "low_battery") return { droop: 0.35, fold: 0, floatK: 0.5 };
      return { droop: 0, fold: 0, floatK: 1 };
    };

    let raf, prev = performance.now() / 1000;
    const eyeCol = new THREE.Color();
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const now = performance.now() / 1000, dt = Math.min(now - prev, 0.05); prev = now;
      const e = emoRef.current, tg = target();
      const k = 1 - Math.exp(-4.5 * dt);
      st.droop += (tg.droop - st.droop) * k;
      st.fold += (tg.fold - st.fold) * (1 - Math.exp(-3 * dt));
      st.floatK += (tg.floatK - st.floatK) * k;

      /* 몸통: 부유 · 떨림 · 기쁨 홉 */
      const burst = now - st.flapT;
      const hop = burst >= 0 && burst < 1.6 ? Math.abs(Math.sin(burst * 9)) * 0.028 * (1 - burst / 1.6) : 0;
      const jit = e === "data_full" && !reduce ? 0.008 : 0;
      pet.root.position.set(
        (Math.random() - 0.5) * 2 * jit,
        Math.sin(now * 2.3) * 0.02 * st.floatK + hop,
        (Math.random() - 0.5) * 2 * jit
      );
      pet.root.rotation.y = burst >= 0 && burst < 1.6 ? Math.sin(burst * 12) * 0.06 * (1 - burst / 1.6) : 0;

      /* 안테나: 처짐(rotX) + 파닥임(rotZ, 좌우 미러) */
      const flapAmp = burst >= 0 && burst < 1.6 ? 0.5 * (1 - burst / 1.6) : st.petting ? 0.24 : 0;
      pet.tips.forEach(({ g, dir }) => {
        g.rotation.x = st.droop;
        g.rotation.z = Math.sin(now * 2 * Math.PI * 8) * flapAmp * dir
          + (e === "data_full" ? Math.sin(now * 40) * 0.04 * dir : 0);
      });

      /* 패널: 절전/동면 접힘 + 시무룩 처짐 */
      pet.panels.forEach(({ g, sx }) => {
        g.rotation.y = sx * st.fold * 1.75;
        g.rotation.z = (e === "sulky" ? -sx * 0.16 : 0) * (1 - st.fold);
      });
      pet.outers.forEach(({ g, sx }) => { g.rotation.y = -sx * st.fold * 2.9; });

      /* 눈 = 상태등 */
      const ec = EYE[e] || EYE.normal;
      eyeCol.setHex(ec.c);
      let inten = ec.base;
      if (ec.mode === "nat") { st.nextBlink -= dt; if (st.nextBlink < 0) st.nextBlink = 2.2 + Math.random() * 2.2; if (st.nextBlink < 0.12) inten = 0.08; }
      else if (ec.mode === "heavy") inten = 0.3 + 0.3 * (0.5 + 0.5 * Math.sin(now * 2.6));
      else if (ec.mode === "fast") inten = 0.7 + 0.45 * (0.5 + 0.5 * Math.sin(now * 34));
      else if (ec.mode === "dim") inten = 0.32 + 0.12 * Math.sin(now * 1.7);
      else if (ec.mode === "pulse") inten = 0.12 + 0.3 * Math.max(0, Math.sin(now * 1.9));
      else if (ec.mode === "off") inten = (now % 3) < 0.1 ? 0.5 : 0.02;
      if (burst >= 0 && burst < 1.6) inten = Math.max(inten, 1.5);
      if (st.petting) inten = Math.max(inten, 1.25);
      if (st.wakeFlash > 0) { st.wakeFlash -= dt * 1.4; inten = Math.max(inten, st.wakeFlash * 2); }
      pet.eyeMat.emissive.copy(eyeCol);
      pet.eyeMat.color.copy(eyeCol).multiplyScalar(0.25 + Math.min(inten, 1) * 0.75);
      pet.eyeMat.emissiveIntensity = inten;

      /* 장비별 마이크로 아이들 */
      const awake = e !== "hibernate" && e !== "powersave";
      const x = pet.extras;
      if (x.turret && awake) { x.turret.head.rotation.y = Math.sin(now * 0.9) * 0.18; x.turret.bar.rotation.x = Math.sin(now * 0.7) * 0.06; }
      if (x.netRing) x.netRing.rotation.z += dt * (awake ? 0.5 : 0.05);
      if (x.arm) {
        x.arm.sh.rotation.z = awake ? Math.sin(now * 1.3) * 0.05 : 0.18;
        const open = burst >= 0 && burst < 1.6 ? Math.abs(Math.sin(burst * 10)) * 0.25 : 0;
        x.arm.claws.forEach(c => { c.g.rotation.x = c.base * (1 + open); });
      }
      if (x.isDrone) pet.root.position.y += Math.sin(now * 4.2) * 0.008 * st.floatK;

      /* 배경 */
      earth.rotation.y += dt * 0.03;
      debris.forEach(c => {
        const u = c.userData; const a = now * u.sp + u.ph;
        c.position.set(Math.cos(a) * u.r, u.yo + Math.sin(a * 1.7) * 0.15, Math.sin(a) * u.r);
        c.rotation.x += dt * 0.4; c.rotation.y += dt * 0.3;
      });

      /* 카메라 (유휴 3초 후 자동 선회) */
      if (!reduce && now - st.lastPtr > 3 && mode === null) st.camAz += dt * 0.12;
      st.camDist += (st.camDistT - st.camDist) * (1 - Math.exp(-6 * dt));
      const cy = 0.12;
      cam.position.set(
        st.camDist * Math.sin(st.camPol) * Math.sin(st.camAz),
        cy + st.camDist * Math.cos(st.camPol),
        st.camDist * Math.sin(st.camPol) * Math.cos(st.camAz)
      );
      cam.lookAt(0, cy, 0);
      renderer.render(scene, cam);
    };
    loop();

    apiRef.current = { swap, flap: () => { st.flapT = performance.now() / 1000; } };
    return () => {
      cancelAnimationFrame(raf); ro.disconnect();
      dom.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      dom.removeEventListener("wheel", onWheel);
      renderer.dispose(); el.removeChild(dom);
    };
  }, []);

  useEffect(() => { apiRef.current && apiRef.current.swap(modelId); }, [modelId]);

  const cur = MODELS.find(m => m.id === modelId);
  const curEmo = EMOTIONS.find(e => e.id === emotion);
  const mono = { fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" };
  const onEmo = (e) => {
    if (e.burst) {
      if (emotion === "hibernate") setEmotion("normal");
      apiRef.current && apiRef.current.flap();
    } else setEmotion(e.id);
  };

  return (
    <div className="relative w-full h-full min-h-screen select-none" style={{ background: "#070C1A", color: "#E8EDF8" }}>
      <div ref={mountRef} className="absolute inset-0" />

      {/* 상단 헤더 */}
      <div className="absolute top-0 left-0 right-0 flex items-start justify-between px-4 pt-4 pointer-events-none">
        <div>
          <div className="uppercase tracking-widest" style={{ ...mono, fontSize: 10, color: "#5E7CA8" }}>
            Mission Control · 캐릭터 관제 콘솔
          </div>
          <div className="font-semibold" style={{ fontSize: 20, letterSpacing: "-0.01em" }}>{cur.name}</div>
          <div style={{ fontSize: 12, color: "#8FA5C8" }}>{cur.trait}</div>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full"
          style={{ background: "rgba(17,26,48,0.75)", border: "1px solid rgba(94,124,168,0.35)", backdropFilter: "blur(6px)" }}>
          <span className="rounded-full" style={{ width: 7, height: 7, background: "#14E0D2", boxShadow: "0 0 8px #14E0D2" }} />
          <span style={{ ...mono, fontSize: 10, color: "#9FD8D3" }}>LIVE</span>
        </div>
      </div>

      {/* 토스트 */}
      {toast && (
        <div className="absolute left-1/2 flex justify-center pointer-events-none" style={{ top: "22%", transform: "translateX(-50%)" }}>
          <div className="px-4 py-2 rounded-full text-center" style={{ background: "rgba(20,224,210,0.12)", border: "1px solid rgba(20,224,210,0.45)", color: "#B8F5EF", fontSize: 12, maxWidth: "88vw", backdropFilter: "blur(6px)" }}>
            {toast}
          </div>
        </div>
      )}

      {/* 하단 컨트롤 덱 */}
      <div className="absolute bottom-0 left-0 right-0 px-3 pb-4 flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <span style={{ ...mono, fontSize: 10, color: "#5E7CA8" }}>TELEMETRY / {curEmo.id.toUpperCase()}</span>
          <span style={{ fontSize: 11, color: "#8FA5C8" }}>{curEmo.info}</span>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {EMOTIONS.map(e => {
            const on = !e.burst && emotion === e.id;
            return (
              <button key={e.id} onClick={() => onEmo(e)}
                className="shrink-0 px-3 py-2 rounded-full"
                style={{
                  fontSize: 12, fontWeight: on ? 600 : 500,
                  background: on ? "rgba(20,224,210,0.16)" : "rgba(17,26,48,0.8)",
                  border: `1px solid ${on ? "rgba(20,224,210,0.6)" : "rgba(94,124,168,0.3)"}`,
                  color: on ? "#9FF0E8" : e.burst ? "#FFD9A0" : "#C6D3EA",
                  backdropFilter: "blur(6px)",
                }}>
                {e.burst ? "✦ " : ""}{e.label}
              </button>
            );
          })}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {MODELS.map(m => {
            const on = modelId === m.id;
            return (
              <button key={m.id} onClick={() => setModelId(m.id)}
                className="shrink-0 px-3 py-2 rounded-xl text-left"
                style={{
                  minWidth: 92, background: on ? "rgba(46,79,163,0.35)" : "rgba(17,26,48,0.8)",
                  border: `1px solid ${on ? "rgba(122,158,240,0.7)" : "rgba(94,124,168,0.3)"}`,
                  backdropFilter: "blur(6px)",
                }}>
                <div style={{ ...mono, fontSize: 9, color: on ? "#AFC4F5" : "#5E7CA8" }}>{m.label}</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: on ? "#EAF0FF" : "#B9C6DF" }}>{m.name.replace("성체 · ", "")}</div>
              </button>
            );
          })}
        </div>

        <div className="text-center" style={{ fontSize: 10.5, color: "#54688C" }}>
          {emotion === "hibernate" ? "위성을 문질러 깨워 주세요 (동면 복귀 시퀀스)" : "위성 탭 = 기쁨 · 문지르기 = 쓰다듬기 · 빈 공간 드래그 = 궤도 회전"}
        </div>
      </div>
    </div>
  );
}
