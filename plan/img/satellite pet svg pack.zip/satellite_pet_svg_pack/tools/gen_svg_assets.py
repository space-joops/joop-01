# -*- coding: utf-8 -*-
"""우주 쓰레기 청소 위성 펫 — 2D SVG 에셋 팩 생성기
· 3D v2(큐트 리디자인)와 동일 팔레트/실루엣의 카와이 '스티커' 스타일(외곽선+파스텔)
· 캐릭터는 리깅형 그룹 id(Panel_L/R, Antenna_Tip, StatusLight …)로 코드 애니메이션 가능
· 감정 7종 포즈 변형 전부 프리베이크 (6캐릭 × 6감정 + normal)
"""
import os, math, random

ROOT = "/home/claude/svg_pack/satellite_pet_svg_pack"
P = dict(body="#FFF7EF", belly="#FFE3C9", panel="#8FC1EF", panelIn="#CDE4F9",
         ant="#FFCE59", eye="#23D9CE", hi="#FFFFFF", cheek="#FFB1C1",
         mouth="#46536B", joint="#7C87A0", arm="#C7CEDB", thr="#97A0B3",
         net="#7FE0A8", magR="#FF8B7E", magT="#FFF3E8", lacc="#C9A0F0",
         llens="#FF8FA6", line="#3E4A63", eyeLow="#FFB13D", eyePow="#FF8A3D",
         eyeSulk="#E8B84A", sky1="#0B1026", sky2="#1C2A4E", earth="#5D9DE8",
         land="#8FE3B8", coin="#FFD98A", ok="#7FE0A8", warn="#FFCE59", bad="#FF8B7E")
LW = 3.5

def save(rel, w, h, body):
    path = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" '
                f'width="{w}" height="{h}" fill="none">\n{body}\n</svg>\n')

def rr(x, y, w, h, rx, fill, sw=LW, stroke=None, extra=""):
    return (f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx:.1f}" '
            f'fill="{fill}" stroke="{stroke or P["line"]}" stroke-width="{sw}" {extra}/>')
def el(cx, cy, rx, ry, fill, sw=LW, stroke=None, extra=""):
    return (f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" rx="{rx:.1f}" ry="{ry:.1f}" '
            f'fill="{fill}" stroke="{stroke or P["line"]}" stroke-width="{sw}" {extra}/>')
def circ(cx, cy, r, fill, sw=LW, stroke=None, extra=""):
    return (f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" fill="{fill}" '
            f'stroke="{stroke or P["line"]}" stroke-width="{sw}" {extra}/>')
def ln(x1, y1, x2, y2, sw=LW, stroke=None, cap="round"):
    return (f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
            f'stroke="{stroke or P["line"]}" stroke-width="{sw}" stroke-linecap="{cap}"/>')
def pth(d, fill="none", sw=LW, stroke=None, extra=""):
    s = stroke or P["line"]
    return f'<path d="{d}" fill="{fill}" stroke="{s}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" {extra}/>'
def g(id_, inner, tr=""):
    t = f' transform="{tr}"' if tr else ""
    i = f' id="{id_}"' if id_ else ""
    return f'<g{i}{t}>\n{inner}\n</g>'

# ── 얼굴: 감정별 눈·입 ─────────────────────────────────────
def eyes(cx, cy, r, mode):
    out = []
    def open_eye(x, col, lid=0.0):
        s = [el(x, cy, r*0.92, r, col)]
        s.append(el(x-r*0.3, cy-r*0.3, r*0.34, r*0.3, P["hi"], sw=0, stroke="none"))
        s.append(el(x+r*0.36, cy+r*0.28, r*0.15, r*0.13, P["hi"], sw=0, stroke="none"))
        if lid > 0:
            s.append(f'<path d="M {x-r*1.05:.1f} {cy-r*1.1:.1f} h {r*2.1:.1f} v {r*2.2*lid:.1f} '
                     f'a {r*1.05:.1f} {r*1.05*(1-lid):.1f} 0 0 1 {-r*2.1:.1f} 0 Z" fill="{P["body"]}"/>')
            yl = cy - r*1.05 + r*2.1*lid
            s.append(pth(f'M {x-r*0.95:.1f} {yl:.1f} Q {x:.1f} {yl+r*0.25:.1f} {x+r*0.95:.1f} {yl:.1f}', sw=LW*0.9))
        return "".join(s)
    X = [cx - 0 if cx == 0 else 0]  # placeholder
    def both(fn):
        return fn(-1) + fn(1)
    if mode == "normal":
        out.append(both(lambda s: open_eye(s*cx if cx else 0, P["eye"])))
    elif mode == "happy":
        out.append(both(lambda s: pth(f'M {s*cx-r:.1f} {cy+r*0.25:.1f} Q {s*cx:.1f} {cy-r*1.05:.1f} {s*cx+r:.1f} {cy+r*0.25:.1f}', sw=LW*1.7)))
    elif mode == "low":
        out.append(both(lambda s: open_eye(s*cx, P["eyeLow"], lid=0.42)))
    elif mode == "data":
        out.append(both(lambda s: open_eye(s*cx, P["eye"])))
    elif mode == "sulky":
        out.append(both(lambda s: open_eye(s*cx, P["eyeSulk"], lid=0.3) +
                        pth(f'M {s*cx-s*r*0.9:.1f} {cy-r*1.25:.1f} L {s*cx+s*r*0.7:.1f} {cy-r*0.75:.1f}', sw=LW)))
    elif mode == "power":
        out.append(both(lambda s: open_eye(s*cx, P["eyePow"], lid=0.62)))
    elif mode == "hiber":
        out.append(both(lambda s: pth(f'M {s*cx-r*0.9:.1f} {cy:.1f} Q {s*cx:.1f} {cy+r*0.85:.1f} {s*cx+r*0.9:.1f} {cy:.1f}', sw=LW*1.7)))
    return "".join(out)

def mouth(cy, mode):
    if mode == "happy":
        return pth(f'M -8 {cy:.1f} Q 0 {cy+9:.1f} 8 {cy:.1f} Z', fill=P["mouth"], sw=LW*0.8)
    if mode == "sulky":
        return pth(f'M -7 {cy+4:.1f} Q 0 {cy-3:.1f} 7 {cy+4:.1f}', sw=LW)
    if mode in ("hiber", "power"):
        return el(0, cy+1, 4.5, 3.2, P["mouth"], sw=LW*0.7)
    return el(0, cy, 5.5, 4, P["mouth"], sw=LW*0.7)

def face_group(eyeR, eyeSp, eyeY, mode, single=False, cheekOn=True):
    s = [g("StatusLight", eyes(0 if single else eyeSp, eyeY, eyeR, mode))]
    s.append(mouth(eyeY + eyeR + 13, mode))
    if cheekOn:
        cx = (0 if single else eyeSp) + eyeR + 14
        for sx in (-1, 1):
            s.append(el(sx*cx, eyeY + eyeR*0.55, eyeR*0.5, eyeR*0.36, P["cheek"], sw=0, stroke="none"))
    return "".join(s)

# ── 캐릭터 파츠 ────────────────────────────────────────────
def wing(sx, hx, hy, wl, wh, rot, outer=0.0, orot=0.0, idp="Panel"):
    x0 = sx*hx
    inner = rr(min(x0, x0+sx*wl), hy-wh/2, wl, wh, wh*0.45, P["panel"]) + \
            rr(min(x0+sx*6, x0+sx*(wl-4)), hy-wh*0.31, wl-10, wh*0.62, wh*0.3, P["panelIn"], sw=0, stroke="none")
    if outer:
        ox = x0 + sx*(wl+3)
        o = rr(min(ox, ox+sx*outer), hy-wh*0.42, outer, wh*0.84, wh*0.38, P["panel"]) + \
            rr(min(ox+sx*5, ox+sx*(outer-3)), hy-wh*0.26, outer-8, wh*0.52, wh*0.26, P["panelIn"], sw=0, stroke="none")
        inner += g(f"{idp}_{'L' if sx<0 else 'R'}_Outer", o, tr=f"rotate({orot:.1f} {ox:.1f} {hy:.1f})")
    return g(f"{idp}_{'L' if sx<0 else 'R'}", inner, tr=f"rotate({rot:.1f} {x0:.1f} {hy:.1f})")

def antenna(bx, by, rod, ballR, tilt, tipRot, idp="Antenna"):
    tip = ln(0, 0, 0, -rod, sw=LW+1.5) + circ(0, -rod, ballR, P["ant"])
    inner = el(0, 0, 9, 6, P["joint"]) + g(idp+"_Tip", tip, tr=f"rotate({tipRot:.1f} 0 0)")
    return g(idp, inner, tr=f"translate({bx:.1f} {by:.1f}) rotate({tilt:.1f})")

CFG = {
 "s1":  dict(bw=150, bh=122, n=34, eyeR=21, eyeSp=31, eyeY=-4, rod=42, ball=15, ears=False, wl=54, wh=38, outer=0, gear=None),
 "s2":  dict(bw=158, bh=136, n=36, eyeR=22, eyeSp=33, eyeY=-2, rod=50, ball=16, ears=False, wl=56, wh=40, outer=46, gear="arm"),
 "s3n": dict(bw=176, bh=150, n=40, eyeR=24, eyeSp=37, eyeY=0,  rod=46, ball=16, ears=True,  wl=62, wh=44, outer=50, gear="net"),
 "s3m": dict(bw=176, bh=150, n=40, eyeR=24, eyeSp=37, eyeY=0,  rod=46, ball=16, ears=True,  wl=62, wh=44, outer=50, gear="mag"),
 "s3l": dict(bw=176, bh=150, n=40, eyeR=24, eyeSp=37, eyeY=0,  rod=46, ball=16, ears=True,  wl=62, wh=44, outer=50, gear="las"),
 "drone": dict(bw=96, bh=82, n=26, eyeR=17, eyeSp=0, eyeY=-1, rod=27, ball=11, ears=False, wl=34, wh=26, outer=0, gear="drone"),
}
EMO = {  # tipRot, wingRot, wingFold(outer), eyeMode, extras
 "normal":     (0,   -6,  0,  "normal"),
 "happy":      (-14, -10, 0,  "happy"),
 "low_battery":(16,  -2,  0,  "low"),
 "data_full":  (0,   -6,  0,  "data"),
 "sulky":      (42,  14,  0,  "sulky"),
 "powersave":  (58,  52,  70, "power"),
 "hibernate":  (76,  84,  120,"hiber"),
}

def build_char(cid, emo="normal"):
    c = CFG[cid]; tipR, wRot, wFold, eyeMode = EMO[emo]
    bw, bh = c["bw"], c["bh"]; cy0 = 12  # 몸 중심을 캔버스 중심보다 살짝 아래
    parts = []
    hy = cy0 + 4
    for sx in (-1, 1):
        parts.append(wing(sx, bw/2 - 6, hy, c["wl"], c["wh"],
                          sx*(wRot), c["outer"], sx*(wFold if wFold else -wRot*0.4)))
    parts.append(el(0, cy0 + bh/2 + 2, 22, 10, P["thr"], extra=f'id="Thruster"'))
    body = rr(-bw/2, cy0-bh/2, bw, bh, c["n"], P["body"])
    body += rr(-bw*0.25, cy0 + bh*0.1, bw*0.5, bh*0.34, c["n"]*0.6, P["belly"], sw=0, stroke="none")
    parts.append(g("Body", body))
    gear = c["gear"]
    if gear == "arm":
        arm = circ(0, 0, 13, P["arm"]) + \
              rr(8, -8, 34, 16, 8, P["arm"]) + circ(44, 0, 10, P["arm"]) + \
              g("Arm_Claw_A", rr(50, -16, 22, 12, 6, P["joint"]), tr="rotate(-14 50 -10)") + \
              g("Arm_Claw_B", rr(50, 4, 22, 12, 6, P["joint"]), tr="rotate(14 50 10)")
        parts.append(g("Arm", arm, tr=f"translate({bw/2-8:.0f} {cy0+16:.0f}) rotate(8)"))
    elif gear == "net":
        net_g = rr(-16, -14, 32, 28, 9, P["joint"]) + \
                g("NetRing", circ(30, -6, 24, "none", sw=LW+2.5, stroke=P["net"]) +
                  "".join(circ(30 + 24*math.cos(math.radians(a)), -6 + 24*math.sin(math.radians(a)), 5.5, P["net"]) for a in (45, 135, 225, 315)))
        parts.append(g("NetLauncher", net_g, tr=f"translate({bw/2-14:.0f} {cy0-bh*0.26:.0f}) rotate(-8)"))
    elif gear == "mag":
        mg = pth(f'M -18 6 A 18 18 0 1 1 18 6', sw=13, stroke=P["magR"]) + \
             rr(-24, 4, 12, 14, 4, P["magT"], extra='id="Magnet_Tip_L"') + \
             rr(12, 4, 12, 14, 4, P["magT"], extra='id="Magnet_Tip_R"')
        parts.append(g("MagnetUnit", mg, tr=f"translate({bw/2+2:.0f} {cy0+8:.0f}) rotate(12)"))
    elif gear == "las":
        tu = el(0, 10, 16, 9, P["joint"]) + rr(-15, -14, 30, 24, 9, P["lacc"]) + \
             g("Laser_Barrel", rr(10, -8, 26, 13, 6.5, P["arm"]) + circ(38, -1.5, 8.5, P["llens"]))
        parts.append(g("Turret_Head", tu, tr=f"translate({bw/2-6:.0f} {cy0-bh/2+6:.0f}) rotate(6)"))
    elif gear == "drone":
        ra = ln(0, 0, 0, 16, sw=LW+1) + \
             rr(-9, 14, 8, 12, 4, P["joint"], extra='transform="rotate(-14 -5 20)"') + \
             rr(1, 14, 8, 12, 4, P["joint"], extra='transform="rotate(14 5 20)"')
        parts.append(g("RepairArm", ra, tr=f"translate(0 {cy0+bh/2-2:.0f})"))
    # 안테나(귀)
    topY = cy0 - bh/2 + 4
    if c["ears"]:
        parts.append(antenna(-bw*0.29, topY, c["rod"], c["ball"], -14, -tipR, "Antenna_L"))
        parts.append(antenna(bw*0.29, topY, c["rod"], c["ball"], 14, tipR, "Antenna_R"))
    else:
        parts.append(antenna(0, topY, c["rod"], c["ball"], 0, tipR))
    # 얼굴
    parts.append(g("Face", face_group(c["eyeR"], c["eyeSp"], cy0 + c["eyeY"] - bh*0.08, eyeMode, single=(cid == "drone"))))
    # 감정 부가 연출
    if emo == "happy":
        for sx in (-1, 1):
            x = sx*(bw/2+22); y = cy0-bh/2-10
            parts.append(pth(f'M {x} {y-9} L {x+3} {y-2} L {x+10} {y} L {x+3} {y+2} L {x} {y+9} L {x-3} {y+2} L {x-10} {y} L {x-3} {y-2} Z', fill=P["warn"], sw=LW*0.7))
    if emo == "data_full":
        parts.append(pth(f'M {bw/2-2} {cy0-bh/2-4} q 8 6 2 16 q -7 -3 -2 -16 Z', fill="#BFE3FF", sw=LW*0.8))
        for sx in (-1, 1):
            for i in range(2):
                x = sx*(bw/2+12+i*8)
                parts.append(ln(x, cy0-14+i*4, x, cy0+16-i*4, sw=LW*0.9))
    if emo == "hibernate":
        zx, zy = bw/2+16, cy0-bh/2-6
        for i, s in enumerate((14, 10, 7)):
            x = zx + i*13; y = zy - i*13
            parts.append(pth(f'M {x-s/2} {y-s/2} h {s} l {-s} {s} h {s}', sw=LW))
    return g(None, "".join(parts), tr="translate(128 130) scale(0.82)")

# ── 캐릭터 출력 ────────────────────────────────────────────
CHAR_FILES = {"s1": "pet_stage1_baby", "s2": "pet_stage2_junior", "s3n": "pet_stage3_net",
              "s3m": "pet_stage3_magnet", "s3l": "pet_stage3_laser", "drone": "support_drone"}
for cid, nm in CHAR_FILES.items():
    save(f"characters/{nm}.svg", 256, 256, build_char(cid, "normal"))
    for emo in EMO:
        if emo == "normal": continue
        save(f"characters/emotions/{nm}__{emo}.svg", 256, 256, build_char(cid, emo))

# 얼굴 시트 (7감정 × 1행)
cells = []
for i, emo in enumerate(EMO):
    m = EMO[emo][3]
    cells.append(g(f"face_{emo}", face_group(20, 30, -6, m), tr=f"translate({60+i*120} 62)"))
save("characters/faces_sheet.svg", 840, 120, "".join(cells))

# ── 파편(수집 대상) 8종 ────────────────────────────────────
def shine(x, y):  # 반짝 틱
    return pth(f'M {x} {y-7} L {x+2} {y-2} L {x+7} {y} L {x+2} {y+2} L {x} {y+7} L {x-2} {y+2} L {x-7} {y} L {x-2} {y-2} Z',
               fill=P["hi"], sw=LW*0.6)
D = {}
D["bolt"] = (circ(0, -14, 17, P["arm"]) + pth('M -17 -14 l 3.4 -8 h 27.2 l 3.4 8', fill=P["arm"], sw=0, stroke="none") +
             rr(-7, 0, 14, 34, 6, P["joint"]) + "".join(ln(-7, 8+i*8, 7, 8+i*8, sw=LW*0.8) for i in range(3)))
D["nut"] = (pth('M 0 -24 L 21 -12 L 21 12 L 0 24 L -21 12 L -21 -12 Z', fill=P["arm"]) + circ(0, 0, 9, P["sky2"]))
D["shard"] = pth('M -22 -8 L 6 -24 L 22 -2 L 10 22 L -14 16 Z', fill=P["joint"]) + ln(-8, -4, 8, 6, sw=LW*0.8)
D["solar_fragment"] = (rr(-24, -18, 48, 36, 6, P["panel"]) +
                       "".join(ln(-24+12*i, -18, -24+12*i, 18, sw=LW*0.7) for i in (1, 2, 3)) +
                       ln(-24, 0, 24, 0, sw=LW*0.7) + pth('M 10 -18 L 24 -18 L 24 -4 Z', fill=P["panelIn"], sw=0, stroke="none"))
D["antenna_piece"] = (ln(-14, 16, 10, -12, sw=LW+1.5) + circ(10, -12, 9, P["ant"]) + el(-14, 18, 8, 5, P["joint"]))
D["fuel_tank"] = (rr(-14, -24, 28, 48, 14, P["magT"]) + rr(-14, -6, 28, 12, 5, P["magR"], sw=0, stroke="none") +
                  el(0, -24, 8, 4, P["joint"]))
D["gear"] = ("".join(rr(-4, -27, 8, 10, 3, P["arm"], extra=f'transform="rotate({a} 0 0)"') for a in range(0, 360, 45)) +
             circ(0, 0, 17, P["arm"]) + circ(0, 0, 7, P["sky2"]))
D["chip"] = (rr(-18, -14, 36, 28, 5, "#57D08A") + rr(-9, -7, 18, 14, 3, P["coin"]) +
             "".join(ln(-18, -8+i*8, -25, -8+i*8, sw=LW*0.8) + ln(18, -8+i*8, 25, -8+i*8, sw=LW*0.8) for i in range(3)))
for nm, body in D.items():
    save(f"debris/{nm}.svg", 96, 96, g(None, body + shine(26, -26), tr="translate(48 50)"))

# ── UI 아이콘 ──────────────────────────────────────────────
U = {}
U["stat_battery"] = (rr(-26, -15, 48, 30, 8, P["body"]) + rr(22, -7, 8, 14, 3, P["joint"]) +
                     "".join(rr(-20+i*13, -9, 10, 18, 3, P["ok"], sw=0, stroke="none") for i in range(3)))
U["stat_durability"] = (pth('M 0 -26 L 22 -17 V 4 Q 22 20 0 28 Q -22 20 -22 4 V -17 Z', fill=P["panel"]) +
                        pth('M 0 12 Q -14 2 -8 -7 Q -3 -12 0 -6 Q 3 -12 8 -7 Q 14 2 0 12 Z', fill=P["cheek"], sw=LW*0.8))
U["stat_data"] = (rr(-22, -18, 44, 36, 7, "#57D08A") + rr(-11, -9, 22, 18, 4, P["coin"]) +
                  pth('M 32 6 V -8 M 26 -2 L 32 -9 L 38 -2', sw=LW+0.5))
U["coin_scrap"] = (circ(0, 0, 26, P["coin"]) + circ(0, 0, 19, "#FFE9B8", sw=LW*0.8) +
                   pth('M -6 -10 h 12 l -8 9 h 8 l -14 12 4 -9 h -8 Z', fill=P["warn"], sw=LW*0.8))
U["evo_crystal"] = (pth('M 0 -26 L 16 -8 L 10 22 L -10 22 L -16 -8 Z', fill=P["lacc"]) +
                    pth('M 0 -26 L 4 22 M -16 -8 L 16 -8', sw=LW*0.8))
for nm, mult, col in (("risk_safe", "×1.0", P["ok"]), ("risk_standard", "×1.5", P["warn"]), ("risk_close", "×2.0", P["bad"])):
    U[nm] = (pth('M 0 -27 L 23 -13 V 13 L 0 27 L -23 13 V -13 Z', fill=col) +
             f'<text x="0" y="7" text-anchor="middle" font-family="sans-serif" font-weight="bold" font-size="17" fill="{P["line"]}">{mult}</text>')
U["gesture_tap"] = (circ(0, 2, 14, P["cheek"]) + circ(0, 2, 22, "none", sw=LW, extra='stroke-dasharray="5 7"') +
                    pth('M 0 -12 V -26 M -9 -21 L 0 -30 L 9 -21', sw=LW))
U["gesture_hold"] = (circ(0, 0, 14, P["cheek"]) +
                     pth('M 0 -24 A 24 24 0 1 1 -17 17', sw=LW+0.5) + pth('M -22 10 L -17 17 L -9 15', sw=LW))
U["gesture_drag"] = (circ(-14, 8, 12, P["cheek"]) + pth('M -2 0 Q 14 -16 26 -6 M 20 -12 L 26 -6 L 19 0', sw=LW+0.5))
U["heart"] = pth('M 0 20 Q -26 2 -15 -12 Q -7 -20 0 -9 Q 7 -20 15 -12 Q 26 2 0 20 Z', fill=P["cheek"])
U["gift"] = (rr(-20, -8, 40, 28, 6, P["magR"]) + rr(-23, -16, 46, 10, 4, P["cheek"]) +
             ln(0, -16, 0, 20, sw=LW) + pth('M 0 -16 Q -12 -30 -4 -31 Q 2 -31 0 -16 Q -2 -31 4 -31 Q 12 -30 0 -16', sw=LW))
U["logbook"] = (rr(-20, -24, 40, 48, 6, P["panel"]) + rr(-20, -24, 10, 48, 4, P["joint"]) +
                ln(-2, -12, 12, -12, sw=LW*0.9) + ln(-2, -2, 12, -2, sw=LW*0.9) + ln(-2, 8, 12, 8, sw=LW*0.9))
U["bell"] = (pth('M -16 12 Q -16 -18 0 -18 Q 16 -18 16 12 Z', fill=P["ant"]) +
             ln(-21, 12, 21, 12, sw=LW) + circ(0, 18, 5, P["ant"]) + circ(9, -20, 6, P["bad"], sw=LW*0.8))
U["capsule_hatch"] = (pth('M -20 6 A 20 24 0 1 1 20 6 Z', fill=P["magT"]) + el(0, 10, 24, 8, P["joint"]) +
                      circ(0, -6, 8, P["eye"]) + pth('M -28 -18 L -20 -10 M 28 -18 L 20 -10 M 0 -36 V -26', sw=LW*0.9))
for nm, body in U.items():
    save(f"ui/{nm}.svg", 96, 96, g(None, body, tr="translate(48 48)"))

# ── 이펙트 ─────────────────────────────────────────────────
E = {}
E["fx_sparkle"] = "".join(pth(f'M {x} {y-s} L {x+s*0.28} {y-s*0.28} L {x+s} {y} L {x+s*0.28} {y+s*0.28} L {x} {y+s} L {x-s*0.28} {y+s*0.28} L {x-s} {y} L {x-s*0.28} {y-s*0.28} Z',
        fill=P["warn"], sw=LW*0.7) for x, y, s in ((-14, -8, 18), (18, 10, 12), (8, -22, 8)))
E["fx_zzz"] = "".join(pth(f'M {x-s/2} {y-s/2} h {s} l {-s} {s} h {s}', sw=LW+0.5)
                      for x, y, s in ((-14, 14, 20), (6, -4, 14), (20, -20, 10)))
E["fx_heart_pop"] = (pth('M 0 16 Q -20 2 -12 -9 Q -5 -16 0 -7 Q 5 -16 12 -9 Q 20 2 0 16 Z', fill=P["cheek"]) +
                     "".join(circ(x, y, 3, P["cheek"], sw=0, stroke="none") for x, y in ((-24, -14), (24, -10), (0, -26))))
E["fx_collect_ring"] = (circ(0, 0, 26, "none", sw=LW+1, stroke=P["eye"]) +
                        circ(0, 0, 15, "none", sw=LW*0.8, stroke=P["eye"], extra='stroke-dasharray="4 6"') +
                        "".join(ln(34*math.cos(math.radians(a)), 34*math.sin(math.radians(a)),
                                   41*math.cos(math.radians(a)), 41*math.sin(math.radians(a)), sw=LW, stroke=P["eye"]) for a in range(0, 360, 45)))
E["fx_laser_beam"] = (rr(-44, -7, 88, 14, 7, P["llens"], sw=0, stroke="none") +
                      rr(-44, -3.2, 88, 6.4, 3.2, "#FFD9E2", sw=0, stroke="none") + circ(44, 0, 10, P["llens"], sw=LW*0.8))
E["fx_net_throw"] = (circ(6, 0, 30, "none", sw=LW+1.5, stroke=P["net"]) +
                     "".join(pth(f'M {6+30*math.cos(math.radians(a))} {30*math.sin(math.radians(a))} Q 6 0 {6+30*math.cos(math.radians(a+90))} {30*math.sin(math.radians(a+90))}',
                                 sw=LW*0.7, stroke=P["net"]) for a in range(0, 360, 45)) +
                     "".join(circ(6+30*math.cos(math.radians(a)), 30*math.sin(math.radians(a)), 4.5, P["net"], sw=LW*0.7) for a in (45, 135, 225, 315)))
E["fx_magnet_field"] = "".join(pth(f'M {-18-i*10} {14+i*4} A {18+i*10} {18+i*10} 0 0 1 {18+i*10} {14+i*4}',
                                   sw=LW, stroke=P["magR"], extra='stroke-dasharray="7 6"') for i in range(3)) + \
                       "".join(circ(x, y, 3, P["magR"], sw=0, stroke="none") for x, y in ((-8, -18), (10, -24), (0, -8)))
E["fx_alert"] = (pth('M 0 -26 L 26 20 Q 28 26 21 26 H -21 Q -28 26 -26 20 Z', fill=P["warn"]) +
                 ln(0, -10, 0, 8, sw=LW+1.5) + circ(0, 17, 3, P["line"], sw=0, stroke=P["line"]))
for nm, body in E.items():
    save(f"effects/{nm}.svg", 96, 96, g(None, body, tr="translate(48 48)"))

# ── 배경 ───────────────────────────────────────────────────
random.seed(7)
stars = "".join(f'<circle cx="{random.uniform(20,1060):.0f}" cy="{random.uniform(20,1500):.0f}" r="{random.choice((1.6,2.2,3)):.1f}" fill="#CFE0FF" opacity="{random.uniform(0.35,0.95):.2f}"/>' for _ in range(90))
big = "".join(pth(f'M {x} {y-s} L {x+s*0.3} {y-s*0.3} L {x+s} {y} L {x+s*0.3} {y+s*0.3} L {x} {y+s} L {x-s*0.3} {y+s*0.3} L {x-s} {y} L {x-s*0.3} {y-s*0.3} Z', fill="#EAF2FF", sw=0, stroke="none")
              for x, y, s in ((160, 240, 10), (880, 420, 8), (540, 150, 7), (930, 1180, 9)))
earth = (f'<circle cx="380" cy="2150" r="640" fill="{P["earth"]}"/>'
         f'<circle cx="380" cy="2150" r="640" fill="none" stroke="#BFE0FF" stroke-width="18" opacity="0.5"/>'
         + el(210, 1660, 120, 62, P["land"], sw=0, stroke="none", extra='opacity="0.9"')
         + el(560, 1590, 90, 48, P["land"], sw=0, stroke="none", extra='opacity="0.9"')
         + el(410, 1760, 70, 36, "#B8F0D4", sw=0, stroke="none", extra='opacity="0.8"'))
bg = (f'<defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">'
      f'<stop offset="0" stop-color="{P["sky1"]}"/><stop offset="1" stop-color="{P["sky2"]}"/></linearGradient></defs>'
      f'<rect width="1080" height="1920" fill="url(#sky)"/>' + stars + big + earth)
save("background/bg_space_portrait.svg", 1080, 1920, bg)
save("background/earth_badge.svg", 256, 256,
     circ(128, 128, 96, P["earth"], sw=LW+2) + el(96, 100, 40, 22, P["land"], sw=0, stroke="none")
     + el(160, 140, 30, 16, P["land"], sw=0, stroke="none") + el(110, 168, 22, 12, "#B8F0D4", sw=0, stroke="none")
     + circ(128, 128, 106, "none", sw=LW, stroke="#BFE0FF", extra='opacity="0.6"'))
random.seed(11)
save("background/stars_tile.svg", 256, 256,
     "".join(f'<circle cx="{random.uniform(8,248):.0f}" cy="{random.uniform(8,248):.0f}" r="{random.choice((1.4,2,2.6)):.1f}" fill="#CFE0FF" opacity="{random.uniform(0.3,0.9):.2f}"/>' for _ in range(26)))

# ── 프리뷰 HTML ─────────────────────────────────────────────
rows = []
for base, _, files in sorted(os.walk(ROOT)):
    rel = os.path.relpath(base, ROOT)
    svgs = sorted(f for f in files if f.endswith(".svg"))
    if not svgs: continue
    cells = "".join(f'<figure><img src="{os.path.join(rel, f)}"/><figcaption>{f}</figcaption></figure>' for f in svgs)
    rows.append(f'<h2>{rel}</h2><div class="grid">{cells}</div>')
html = ('<!doctype html><meta charset="utf-8"><title>SVG Asset Pack Preview</title><style>'
        'body{background:#0d1326;color:#cdd9f5;font-family:sans-serif;padding:24px}'
        '.grid{display:flex;flex-wrap:wrap;gap:14px}figure{margin:0;text-align:center}'
        'img{width:110px;height:110px;background:#182241;border-radius:12px;padding:6px}'
        'figcaption{font-size:10px;margin-top:4px;opacity:.7}h2{margin:26px 0 10px;font-size:14px;color:#8fa5d9}'
        '</style>' + "".join(rows))
open(os.path.join(ROOT, "_preview.html"), "w").write(html)

total = sum(len([f for f in fs if f.endswith('.svg')]) for _, _, fs in os.walk(ROOT))
print(f"SVG files: {total}")
