# 우주 쓰레기 청소 위성 펫 — 2D SVG 에셋 팩

기획서 V3 / V3.5 사양의 2D 개발용 벡터 에셋 전체 세트입니다. 3D 팩 v2(큐트 리디자인)와 동일한 팔레트·실루엣을 쓰는 카와이 '스티커' 스타일(파스텔 + 외곽선 `#3E4A63`)이라 두 파이프라인을 섞어도 톤이 유지됩니다. 압축을 푼 뒤 `_preview.html`을 브라우저로 열면 78개 파일 전체를 한눈에 볼 수 있습니다.

## 구성 (SVG 78개)

| 폴더 | 개수 | 내용 |
|---|---|---|
| `characters/` | 6 + 시트 1 | 캐릭터 6종 기본(normal) 포즈 — 리깅형 그룹 id 포함 |
| `characters/emotions/` | 36 | 6종 × 6감정 프리베이크 변형 (`이름__감정.svg`) |
| `debris/` | 8 | 수집 대상 파편: 볼트·너트·금속 조각·태양광 파편·안테나 조각·연료탱크·기어·칩 |
| `ui/` | 16 | 상태 게이지 3종 · 재화 2종 · 위험 수당 배지 3종 · 제스처 힌트 3종 · 하트/선물/항해일지/알림종/부화 캡슐 |
| `effects/` | 8 | 반짝임 · Zzz · 하트 팝 · 수집 링 · 레이저 빔 · 그물 투척 · 자기장 · 경고 |
| `background/` | 3 | 세로 배경(1080×1920) · 지구 배지 · 별 타일 |

## 규격

캐릭터는 256×256 viewBox, 본체 중심 앵커 약 (128, 130). 파편·UI·이펙트는 96×96, 중심 (48, 48). 배경은 1080×1920 세로(9:16). 전부 벡터라 무손실 확대되며, 래스터로 굽는다면 캐릭터 @1x 256px(레티나 512px), 아이콘 @1x 96px을 권장합니다. 외곽선 두께는 캐릭터 캔버스 기준 3.5px — 극단적으로 축소 시(<48px) 두께가 뭉치므로 아이콘류를 대신 쓰세요.

## 캐릭터 6종

| 파일 | 캐릭터 | 장비 |
|---|---|---|
| `pet_stage1_baby` | 1단계 아기 | 보블 안테나 1개, 단일 날개 |
| `pet_stage2_junior` | 2단계 청소년 | 미튼 로봇 팔 + 2단 날개 |
| `pet_stage3_net` | 3단계 · 그물망 | 구슬 4개 그물 후프 |
| `pet_stage3_magnet` | 3단계 · 자석 | 말굽자석 |
| `pet_stage3_laser` | 3단계 · 레이저 | 파티혼 터렛 |
| `support_drone` | 보조 드론 | 외눈 + 수리 팔 |

## 2D 리그 — 그룹 id로 코드 애니메이션

기본(normal) 캐릭터 파일은 3D 팩과 같은 이름 체계의 `<g id>`로 파츠가 나뉘어 있고, 각 힌지 그룹의 rotate 기준점이 관절 위치로 잡혀 있습니다. 웹(CSS/JS·Lottie 변환)이나 SVG 노드 접근이 되는 엔진에서 그룹 transform만 바꾸면 감정 연출이 됩니다.

| 그룹 id | 조작 |
|---|---|
| `Antenna` → `Antenna_Tip` (3단계는 `Antenna_L/R`) | Tip rotate = 파닥임(기쁨) / 처짐(방치) |
| `Panel_L` / `Panel_R` (+`_Outer`) | rotate = 날개 처짐·접힘. `_Outer`는 아코디언 |
| `StatusLight` | 눈 = 상태등. fill 색·opacity로 기분 표시 |
| `Body` `Face` `Thruster` | 호버 바운스·떨림은 루트 translate로 |
| `Arm` `Arm_Claw_A/B` · `NetLauncher` `NetRing` · `MagnetUnit` `Magnet_Tip_L/R` · `Turret_Head` `Laser_Barrel` · `RepairArm` | 장비 마이크로 아이들 |

## 감정 변형 (프리베이크 36종)

스프라이트 스왑만 하는 파이프라인용으로 6감정을 모두 구워 두었습니다: `happy` `low_battery` `data_full` `sulky` `powersave` `hibernate` (+기본 normal). 직접 포즈를 돌리고 싶다면 아래 값이 프리베이크에 쓰인 파라미터입니다 — `character_data.json`(3D 팩)의 emotion_states와 동일 논리입니다.

| 감정 | 안테나 Tip 회전 | 날개 회전 | 바깥 날개 추가 접힘 | 눈 |
|---|---|---|---|---|
| normal | 0° | -6°(살짝 위) | — | 청록 큰 눈 |
| happy | -14°(쫑긋) | -10° | — | ∩∩ 웃는 눈 + 반짝 |
| low_battery | +16° | -2° | — | 호박색, 42% 감김 |
| data_full | 0° | -6° | — | 청록 + 땀방울·진동선 |
| sulky | +42° | +14°(처짐) | — | 황갈색, 30% 감김 + 팔자 눈썹 |
| powersave | +58° | +52°(접힘) | +70° | 주황, 62% 감김 |
| hibernate | +76° | +84°(완전 접힘) | +120° | 감은 눈 ‿‿ + Zzz |

`faces_sheet.svg`(840×120)는 7감정 얼굴만 모은 시트로, 120px 셀 단위로 잘라 얼굴 스왑 방식에 쓸 수 있습니다.

## 용도 매핑 (기획서 ↔ 에셋)

상태 지표 HUD는 `stat_battery`(포만감) · `stat_durability`(내구도=하트 실드) · `stat_data`(데이터 용량, 전송 화살표). 위험 수당제 선택 UI는 `risk_safe ×1.0` / `risk_standard ×1.5` / `risk_close ×2.0` 육각 배지. 온보딩 90초의 제스처 튜토리얼은 `gesture_tap`(수집·요격) `gesture_hold`(조준 발사) `gesture_drag`(쓰다듬기·포획·깨우기), 발사(부화) 연출은 `capsule_hatch`. 복귀 시퀀스 보상은 `logbook`(항해 일지)과 `gift`(선물), 쓰다듬기 무료 수리는 `heart` + `fx_heart_pop`. 감정형 알림 아이콘은 `bell`. 수집 연출은 `fx_collect_ring`, 3단계 분기 스킬은 `fx_laser_beam` `fx_net_throw` `fx_magnet_field`, 방치 연출은 `fx_zzz`, 근접 티어 경고는 `fx_alert`. 재화는 `coin_scrap`(고철 코인)과 `evo_crystal`(진화 재료 — 전 티어 확정 드롭 가드레일 대상).

## 팔레트

| 용도 | HEX | 용도 | HEX |
|---|---|---|---|
| 몸통 | `#FFF7EF` | 배 | `#FFE3C9` |
| 날개 | `#8FC1EF` | 날개 안쪽 | `#CDE4F9` |
| 안테나 방울 | `#FFCE59` | 눈(평상) | `#23D9CE` |
| 눈(배터리 부족) | `#FFB13D` | 눈(절전) | `#FF8A3D` |
| 눈(시무룩) | `#E8B84A` | 볼터치 | `#FFB1C1` |
| 외곽선 | `#3E4A63` | 관절·장식 | `#7C87A0` |
| 그물 | `#7FE0A8` | 자석 | `#FF8B7E` |
| 레이저 액센트 | `#C9A0F0` | 레이저 렌즈 | `#FF8FA6` |
| 긍정/안전 | `#7FE0A8` | 경고/근접 | `#FFCE59` / `#FF8B7E` |

## 엔진별 사용 팁

웹·React Native는 SVG를 그대로 쓰거나 인라인해 그룹 id로 애니메이션하면 됩니다. Unity는 Vector Graphics(SVG Importer) 패키지 또는 위 권장 해상도로 래스터화, Godot 4는 SVG 텍스처를 기본 지원합니다. 위험 수당 배지의 배율 숫자는 `<text>`(sans-serif)라 폰트 임베드가 필요한 파이프라인이면 래스터화하거나 배지 위에 자체 폰트로 얹으세요.

## 커스터마이징

`tools/gen_svg_assets.py`의 `P`(팔레트) · `CFG`(캐릭터 치수: 몸 `bw/bh`, 모서리 `n`, 눈 `eyeR` 등) · `EMO`(감정 포즈 값)를 수정한 뒤 실행하면 78개 파일이 일괄 재생성됩니다. 필요 패키지: 표준 파이썬만 (`python3 gen_svg_assets.py`).

---
2026-07-20 · 기획서 V3 + V3.5 보강문서 기준 · 3D 팩 v2와 팔레트 공유
